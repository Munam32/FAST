#include <stdio.h>
#include <stdlib.h>

void insertionSort(int arr[], int size) {
    for (int i = 1; i < size; i++) {
        int key = arr[i], j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

int main() {
    FILE *file = fopen("right_half.txt", "r");
    int size;
    fscanf(file, "%d", &size);
    int *arr = (int *)malloc(size * sizeof(int));

    for (int i = 0; i < size; i++) fscanf(file, "%d", &arr[i]);
    fclose(file);

    insertionSort(arr, size);

    file = fopen("right_half.txt", "w");
    fprintf(file, "%d\n", size);
    for (int i = 0; i < size; i++) fprintf(file, "%d ", arr[i]);
    fclose(file);

    free(arr);
    return 0;
}

