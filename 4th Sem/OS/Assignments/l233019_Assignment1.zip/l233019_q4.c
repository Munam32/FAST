#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    int n;

    // User inputs matrix size
    printf("Enter the size of the square matrix (n x n): ");
    scanf("%d", &n);

    int A[n][n], B[n][n], C[n][n]; // Matrices A, B, and Result C
    int pipes[n][2]; // Pipes for communication

    // User inputs matrices A and B
    printf("Enter matrix A (%d x %d):\n", n, n);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            scanf("%d", &A[i][j]);

    printf("Enter matrix B (%d x %d):\n", n, n);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            scanf("%d", &B[i][j]);

    // Creating n child processes (one for each row)
    for (int i = 0; i < n; i++) {
        if (pipe(pipes[i]) == -1) { // Create a pipe for each child
            perror("Pipe failed");
            exit(1);
        }

        pid_t pid = fork();
        if (pid == -1) {
            perror("Fork failed");
            exit(1);
        }

        if (pid == 0) { // Child process
            close(pipes[i][0]); // Close reading end of the pipe

            int row[n]; // Compute row of matrix C
            for (int j = 0; j < n; j++)
                row[j] = A[i][j] + B[i][j];

            // Send the computed row to the parent process
            write(pipes[i][1], row, sizeof(row));
            close(pipes[i][1]); // Close writing end
            exit(0);
        }
    }

    // Parent process collects data from pipes
    for (int i = 0; i < n; i++) {
        close(pipes[i][1]); // Close writing end in parent
        read(pipes[i][0], C[i], sizeof(C[i])); // Read row from pipe
        close(pipes[i][0]); // Close reading end
    }

    // Parent waits for all child processes to finish
    for (int i = 0; i < n; i++) {
        wait(NULL);
    }

    // Print the final matrix C
    printf("Resultant Matrix C (A + B):\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++)
            printf("%d ", C[i][j]);
        printf("\n");
    }

    return 0;
}

