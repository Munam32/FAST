#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

#define FIFO_NAME "myfifo"
#define BUFFER_SIZE 1024

// Function to count words in a string
int count_words(char *message) {
    int count = 0;
    char *token = strtok(message, " \t\n");
    while (token != NULL) {
        count++;
        token = strtok(NULL, " \t\n");
    }
    return count;
}

int main() {
    char message[BUFFER_SIZE];

    // Create FIFO (named pipe)
    mkfifo(FIFO_NAME, 0666);

    pid_t pid = fork(); // Create child process

    if (pid < 0) {
        perror("Fork failed");
        exit(1);
    }

    else if (pid == 0) { 
        // CHILD PROCESS (Reader)
        int fd = open(FIFO_NAME, O_RDONLY);
        if (fd == -1) {
            perror("Error opening FIFO for reading");
            exit(1);
        }

        read(fd, message, BUFFER_SIZE);
        close(fd);

        printf("Received message: %s", message);

        // Count words in message
        int word_count = count_words(message);
        printf("Word count: %d\n", word_count);

        unlink(FIFO_NAME); // Remove FIFO after use
    } 
    else {
        // PARENT PROCESS (Writer)
        printf("Enter a message: ");
        fgets(message, BUFFER_SIZE, stdin);

        int fd = open(FIFO_NAME, O_WRONLY);
        if (fd == -1) {
            perror("Error opening FIFO for writing");
            exit(1);
        }

        write(fd, message, strlen(message) + 1);
        close(fd);
        
         // Wait for child to finish
         wait(NULL);
    }

    return 0;
}
