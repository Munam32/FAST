#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

// Function to check if a number is prime
int is_prime(int num) {
    if (num < 2) return 0;
    for (int i = 2; i * i <= num; i++)
        if (num % i == 0) return 0;
    return 1;
}

// Function for child processes to find prime numbers in a given range
void find_primes(int start, int end, int pipe_fd) {
    char result[1024] = ""; // Store prime numbers as a string
    char buffer[20]; // Temporary buffer

    for (int i = start; i <= end; i++) {
        if (is_prime(i)) {
            sprintf(buffer, "%d ", i);
            strcat(result, buffer);
        }
    }

    // Send the result to the parent through the pipe
    write(pipe_fd, result, strlen(result) + 1);
    close(pipe_fd);
    exit(0);
}

int main() {
    int start, end;
    printf("Enter the range (start end): ");
    scanf("%d %d", &start, &end);

    if (start > end) {
        fprintf(stderr, "Invalid range! Start should be less than or equal to End.\n");
        exit(1);
    }

    int mid = (start + end) / 2;
    int pipe1[2], pipe2[2]; // Pipes for communication

    // Create pipes
    if (pipe(pipe1) == -1 || pipe(pipe2) == -1) {
        perror("Pipe creation failed");
        exit(1);
    }

    pid_t pid1 = fork(); // First child
    if (pid1 < 0) {
        perror("Fork failed");
        exit(1);
    }
    else if (pid1 == 0) {
        close(pipe1[0]); // Close read end
        find_primes(start, mid, pipe1[1]); // Find primes in lower half
    }

    pid_t pid2 = fork(); // Second child
    if (pid2 < 0) {
        perror("Fork failed");
        exit(1);
    }
    else if (pid2 == 0) {
        close(pipe2[0]); // Close read end
        find_primes(mid + 1, end, pipe2[1]); // Find primes in upper half
    }

    // Parent process
    close(pipe1[1]); // Close write end of pipe1
    close(pipe2[1]); // Close write end of pipe2

    char primes_lower[1024], primes_upper[1024];

    // Read results from pipes
    read(pipe1[0], primes_lower, sizeof(primes_lower));
    read(pipe2[0], primes_upper, sizeof(primes_upper));

    // Close read ends
    close(pipe1[0]);
    close(pipe2[0]);

    // Wait for child processes to finish
    wait(NULL);
    wait(NULL);

    // Print final results
    printf("Prime numbers in range (%d - %d):\n", start, end);
    printf("Lower half (%d - %d): %s\n", start, mid, primes_lower);
    printf("Upper half (%d - %d): %s\n", mid + 1, end, primes_upper);

    return 0;
}
