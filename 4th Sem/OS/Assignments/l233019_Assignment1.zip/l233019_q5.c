#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
        exit(1);
    }

    pid_t pid1;

    // First child process to execute `cat`
    pid1 = fork();
    if (pid1 < 0) {
        perror("Fork failed");
        exit(1);
    }
    
    if (pid1 == 0) {
        // First child executes `cat filename`
        execlp("cat", "cat", argv[1], NULL);
        perror("execlp cat failed"); // If execlp fails
        exit(1);
    }
    
    wait(NULL);


    // Second child process to execute `wc`
    pid_t pid2 = fork();
    if (pid2 < 0) {
        perror("Fork failed");
        exit(1);
    }
    if (pid2 == 0) {
        // Second child executes `wc filename`
        execlp("wc", "wc", argv[1], NULL);
        perror("execlp wc failed"); // If execlp fails
        exit(1);
    }

    
    wait(NULL);

    return 0;
}
