#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

void merge(int arr[], int left[], int leftSize, int right[], int rightSize) {
    int i = 0, j = 0, k = 0;
    while (i < leftSize && j < rightSize) {
        if (left[i] < right[j])
            arr[k++] = left[i++];
        else
            arr[k++] = right[j++];
    }
    while (i < leftSize) arr[k++] = left[i++];
    while (j < rightSize) arr[k++] = right[j++];
}

int main() {
    int size;
    
    // using files for simplicity ni tou pipes say bhi ho jayay ga
    // User enters array size
    printf("Enter the size of the array: ");
    scanf("%d", &size);

    int *arr = (int *)malloc(size * sizeof(int));
    
    // User enters array elements
    printf("Enter %d elements: ", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr[i]);
    }

    int leftSize = size / 2, rightSize = size - leftSize;
    
    // Write both halves to files
    FILE *file = fopen("left_half.txt", "w");
    fprintf(file, "%d\n", leftSize); // Store size first
    for (int i = 0; i < leftSize; i++) fprintf(file, "%d ", arr[i]);
    fclose(file);

    file = fopen("right_half.txt", "w");
    fprintf(file, "%d\n", rightSize); // Store size first
    for (int i = 0; i < rightSize; i++) fprintf(file, "%d ", arr[leftSize + i]);
    fclose(file);

    // Create first child process
    pid_t pid1 = fork();
    if (pid1 == 0) {  
        execl("./merge_sort", "merge_sort", NULL);
        perror("exec failed for merge_sort_child");
        exit(1);
    }

    // Create second child process
    pid_t pid2 = fork();
    if (pid2 == 0) {  
        execl("./insertion_sort", "insertion_sort", NULL);
        perror("exec failed for insertion_sort_child");
        exit(1);
    }

    // Parent waits for both children
    wait(NULL);
    wait(NULL);

    // Read sorted halves from files
    int *left = (int *)malloc(leftSize * sizeof(int));
    int *right = (int *)malloc(rightSize * sizeof(int));

    file = fopen("left_half.txt", "r");
    fscanf(file, "%d", &leftSize);
    
    for (int i = 0; i < leftSize; i++) fscanf(file, "%d", &left[i]);
    fclose(file);

    file = fopen("right_half.txt", "r");
    fscanf(file, "%d", &rightSize);
    for (int i = 0; i < rightSize; i++) fscanf(file, "%d", &right[i]);
    fclose(file);

    // Merge sorted halves
    merge(arr, left, leftSize, right, rightSize);

    // Print final sorted array
    printf("Merged Sorted Array: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    free(arr);
    free(left);
    free(right);

    return 0;
}

