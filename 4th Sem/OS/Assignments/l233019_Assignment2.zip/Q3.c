#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <fcntl.h>
#include <sys/wait.h>

#define NUM_CUSTOMERS 10

sem_t* ticket_sem;
int tickets = 10;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void* book_ticket(void* arg) {
    int tid = *(int*)arg;

    sem_wait(ticket_sem);
    pthread_mutex_lock(&lock);

    if (tickets > 0) {
        tickets--;
        printf("Ticket booked by customer in thread %d. Tickets left: %d\n", tid, tickets);
    } else {
        printf("Customer in thread %d: No tickets left!\n", tid);
    }

    pthread_mutex_unlock(&lock);
    sem_post(ticket_sem);

    return NULL;
}

void create_customers(const char* process_name) {
    pthread_t threads[NUM_CUSTOMERS];
    int ids[NUM_CUSTOMERS];

    printf("%s: Ticket counter started.\n", process_name);

    for (int i = 0; i < NUM_CUSTOMERS; i++) {
        ids[i] = i;
        pthread_create(&threads[i], NULL, book_ticket, &ids[i]);
        usleep(10000); // sleep to simulate slight delay
    }

    for (int i = 0; i < NUM_CUSTOMERS; i++) {
        pthread_join(threads[i], NULL);
    }
}

int main() {
    ticket_sem = sem_open("/ticketsem", O_CREAT | O_EXCL, 0644, 1);
    if (ticket_sem == SEM_FAILED) {
        perror("sem_open");
        sem_unlink("/ticketsem");
        ticket_sem = sem_open("/ticketsem", O_CREAT, 0644, 1);
    }

    pid_t pid = fork();

    if (pid == 0) {
        // Child Process
        sleep(1); // Delay to simulate async start
        create_customers("Child process");
        exit(0);
    } else {
        // Parent Process
        create_customers("Parent process");
        wait(NULL); // Wait for child to finish
        printf("Parent process finished. Tickets remaining: %d\n", tickets);
        sem_unlink("/ticketsem");
    }

    return 0;
}

