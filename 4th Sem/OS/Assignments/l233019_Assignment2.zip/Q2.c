#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#define NUM_ACCOUNTS 5

int accounts[NUM_ACCOUNTS];
sem_t account_locks[NUM_ACCOUNTS];

void* deposit(void* arg) {
    int* data = (int*) arg;
    int acc = data[0];
    int amount = data[1];

    sem_wait(&account_locks[acc]);
    accounts[acc] += amount;
    printf("Deposited %d to account %d. New balance: %d\n", amount, acc, accounts[acc]);
    sem_post(&account_locks[acc]);

    free(arg);
    return NULL;
}

void* withdraw(void* arg) {
    int* data = (int*) arg;
    int acc = data[0];
    int amount = data[1];

    sem_wait(&account_locks[acc]);
    if (accounts[acc] >= amount) {
        accounts[acc] -= amount;
        printf("Withdrew %d from account %d. New balance: %d\n", amount, acc, accounts[acc]);
    } else {
        printf("Insufficient funds in account %d for withdrawal of %d.\n", acc, amount);
    }
    sem_post(&account_locks[acc]);

    free(arg);
    return NULL;
}

int main() {
    pthread_t tid;
    for (int i = 0; i < NUM_ACCOUNTS; i++) {
        accounts[i] = 1000;
        sem_init(&account_locks[i], 0, 1);
    }

    while (1) {
        int choice, acc, amount;
        printf("\nChoose transaction:\n1. Deposit\n2. Withdraw\n3. Exit\nChoice: ");
        scanf("%d", &choice);
        if (choice == 3) break;

        printf("Enter account number (0 to %d): ", NUM_ACCOUNTS - 1);
        scanf("%d", &acc);
        if (acc < 0 || acc >= NUM_ACCOUNTS) {
            printf("Invalid account number.\n");
            continue;
        }

        printf("Enter amount: ");
        scanf("%d", &amount);

        int* data = malloc(2 * sizeof(int));
        data[0] = acc;
        data[1] = amount;

        if (choice == 1)
            pthread_create(&tid, NULL, deposit, data);
        else if (choice == 2)
            pthread_create(&tid, NULL, withdraw, data);
        else {
            printf("Invalid option.\n");
            free(data);
            continue;
        }

        pthread_join(tid, NULL);
    }

    printf("\nFinal balances:\n");
    for (int i = 0; i < NUM_ACCOUNTS; i++)
        printf("Account %d: %d\n", i, accounts[i]);

    for (int i = 0; i < NUM_ACCOUNTS; i++)
        sem_destroy(&account_locks[i]);

    return 0;
}
