#include<string.h>
#include<iostream>
#include<stdexcept>	//stdexcept header contains runtime_error
using namespace std;

class DivideByZeroException
{
	char* myWhat;
public:
	DivideByZeroException(){
		char msg[] = "divide by zero";
		
		this->myWhat = new char[strlen(msg)+1];
		strcpy(this->myWhat, msg);
		
		cout << "..........DivideByZeroException().\n";
	}
	char* what(){
		return myWhat;
	}
	~DivideByZeroException(){ cout << "~DivideByZeroException().\n"; }
};

//class DivideByZeroException : public std::runtime_error
//{
//public:
//	DivideByZeroException() : std::runtime_error("Program attempted to divide by zero"){
//		cout << "..........DivideByZeroException().\n";
//	}
//	~DivideByZeroException(){ cout << "~DivideByZeroException().\n"; }
//};


double Quotient(int numerator, int denominator)
{
	if (denominator == 0)
		throw DivideByZeroException();	//This is throw point. Function will terminate here.

	return ((double)numerator) / denominator;
}

void Test1()
{
	int n1;
	int n2;

	cout << "Enter two integers:\t";
	cin >> n1 >> n2;

	try
	{
		//try block contains code that might throw exception

		double result = Quotient(n1, n2);
		cout << "The quotient is:\t" << result << endl;
	}
	//Uncomment this when your DivByZeroEx class is not inherited from exception hierarchy to check if base class' handler is catching it or not.
	//catch (DivideByZeroException &ex)
	//{
	//	cout << "Exception occured: " << ex.what() << endl;
	//}
	catch (exception &ex)
	{
		cout << "CHECK THIS: Exception occured: " << ex.what() << endl;
	}
	//Is it catching unknown exceptions //Ellipses
	catch(...){
		cout << "Is it catching unknown exceptions" << endl;
	}
	cout << "Last line of main.\n";
}

void Test2()
{
	int n1;
	int n2;

	cout << "Enter two integers:\t";
	cin >> n1 >> n2;

		

		double result = Quotient(n1, n2);
		cout << "The quotient is:\t" << result << endl;
}

void main()
{
	Test1();
	//Test2();
}