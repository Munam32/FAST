#include <iostream>
using namespace std;
class Date
{
private:

	int Day, Month, Year;


public:
	Date();
	Date(int, int, int);
	~Date();
	void print();
	void Input();
	void SetMonth(int);
	void SetYear(int);
	void SetDay(int);
	int GetDay();
	int GetMonth();
	int GetYear();
	int CompareDate(Date);
	Date IncrementMonth();
	
};