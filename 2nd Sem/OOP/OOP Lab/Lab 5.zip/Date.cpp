#include<iostream>
using namespace std;
#include "Date.h"

Date::Date()
{
	cout << "Default Constructor Called\n\n";

	Day = 1;
	Month = 1;
	Year = 1926;

}

Date::Date(int date_p,int month_p,int year_p)
{
	cout << "Overloaded fuction called\n\n";

	Day = date_p;
	Month = month_p;
	Year = year_p;

	
}


void Date:: print()
{
	cout << Day << '/' << Month << '/' << Year<<"\n\n";
}

void Date::Input()
{
	
	cout << "Enter Day: ";
	cin >> Day;

	cout << "Enter Month: ";
	cin >> Month;

	cout << "Enter Year: ";
	cin >> Year;
}

Date::~Date()
{
	cout << "Destructor called\n";
}

void Date::SetMonth(int month_p)
{
	Month = month_p;
}

void Date::SetDay(int day_p)
{
	Day = day_p;
}

void Date::SetYear(int year_p)
{
	Year = year_p;
}

int Date::GetDay()
{
	return Day;
}

int Date::GetMonth()
{
	return Month;
}

int Date::GetYear()
{
	return Year;
}

int Date::CompareDate(Date rhs)
{
	if (Day == rhs.Day && Month == rhs.Month && Year == rhs.Year)
		return 0;

	else if (Day > rhs.Day || Month > rhs.Month || Year > rhs.Year)
		return 1;
	else
		return -1;
}

Date Date::IncrementMonth()
{
	Date temp;
	
	temp.Day = Day;
	temp.Month = Month;
	
	if (Month == 12)
		temp.Month = 1;
	else
		temp.Month++;

	temp.Year = Year;

	return temp;
}