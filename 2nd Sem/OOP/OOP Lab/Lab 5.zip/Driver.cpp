# include <iostream>
#include "Date.h"
using namespace std;


void main()
{

	Date date1;
	date1.print();

	
	Date independanceDay(14, 8, 1947);
	independanceDay.print();

	date1.Input();
	date1.print();


	Date xmasDay;
	xmasDay.print();

	xmasDay.SetDay(25);
	xmasDay.SetMonth(12);
	xmasDay.SetYear(2018);

	cout << xmasDay.GetDay() << "/" << xmasDay.GetMonth() << "/" << xmasDay.GetYear()<<"\n";

	Date temp = xmasDay;

	temp.print();

	cout << temp.CompareDate(xmasDay)<<"\n\n";

	temp = independanceDay.IncrementMonth();
	temp.print();

	cout << "\n";
	system("pause");
}