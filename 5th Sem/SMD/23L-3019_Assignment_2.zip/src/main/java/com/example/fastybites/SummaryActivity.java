package com.example.fastybites;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SummaryActivity extends AppCompatActivity {

    private TextView tvCustomerName, tvOrderType, tvAddress, tvPaymentMethod;
    private LinearLayout llOrderItems;
    private TextView tvTotalBill;
    private Button btnShareOrder, btnBackToMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        initializeViews();
        displayOrderSummary();
        setupListeners();
    }

    private void initializeViews() {
        tvCustomerName = findViewById(R.id.tvCustomerName);
        tvOrderType = findViewById(R.id.tvOrderType);
        tvAddress = findViewById(R.id.tvAddress);
        tvPaymentMethod = findViewById(R.id.tvPaymentMethod);
        llOrderItems = findViewById(R.id.llOrderItems);
        tvTotalBill = findViewById(R.id.tvTotalBill);
        btnShareOrder = findViewById(R.id.btnShareOrder);
        btnBackToMenu = findViewById(R.id.btnBackToMenu);
    }

    private void displayOrderSummary() {
        Intent intent = getIntent();

        // Get data from intent
        String name = intent.getStringExtra("name");
        String orderType = intent.getStringExtra("orderType");
        String address = intent.getStringExtra("address");
        String paymentMethod = intent.getStringExtra("paymentMethod");
        String orderItems = intent.getStringExtra("orderItems");
        double totalBill = intent.getDoubleExtra("totalBill", 0.0);

        // Display customer info
        tvCustomerName.setText("Name: " + name);
        tvOrderType.setText("Order Type: " + orderType);
        tvAddress.setText("Address: " + address);
        tvPaymentMethod.setText("Payment Method: " + paymentMethod);

        // Display order items
        if (orderItems != null && !orderItems.isEmpty()) {
            String[] items = orderItems.split(",");
            for (String item : items) {
                if (!item.trim().isEmpty()) {
                    String[] parts = item.split("\\|");
                    if (parts.length == 3) {
                        String itemName = parts[0];
                        int quantity = Integer.parseInt(parts[1]);
                        double price = Double.parseDouble(parts[2]);
                        double itemTotal = quantity * price;

                        addOrderItemView(itemName, quantity, price, itemTotal);
                    }
                }
            }
        }

        // Display total bill
        tvTotalBill.setText(String.format("$%.2f", totalBill));
    }

    private void addOrderItemView(String itemName, int quantity, double price, double itemTotal) {
        // Create TextView for item
        TextView tvItem = new TextView(this);
        tvItem.setTextSize(16);
        tvItem.setPadding(16, 12, 16, 12);
        tvItem.setTextColor(ContextCompat.getColor(this, android.R.color.black));

        String itemText = String.format("%s\nQuantity: %d × $%.2f = $%.2f",
                itemName, quantity, price, itemTotal);
        tvItem.setText(itemText);

        llOrderItems.addView(tvItem);

        // Add divider
        View divider = new View(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1);
        params.setMargins(0, 8, 0, 8);
        divider.setLayoutParams(params);
        divider.setBackgroundColor(ContextCompat.getColor(this, android.R.color.darker_gray));
        llOrderItems.addView(divider);
    }

    private void setupListeners() {
        btnShareOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareOrder();
            }
        });

        btnBackToMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void shareOrder() {
        // Create PDF and share
        createAndSharePDF();
    }

    private void createAndSharePDF() {
        Intent intent = getIntent();

        String name = intent.getStringExtra("name");
        String orderType = intent.getStringExtra("orderType");
        String address = intent.getStringExtra("address");
        String paymentMethod = intent.getStringExtra("paymentMethod");
        String orderItems = intent.getStringExtra("orderItems");
        double totalBill = intent.getDoubleExtra("totalBill", 0.0);

        try {
            // Create PDF file in app's cache directory
            String fileName = "Fasty_Bites_Order_" + System.currentTimeMillis() + ".pdf";
            java.io.File pdfFile = new java.io.File(getCacheDir(), fileName);

            com.itextpdf.kernel.pdf.PdfWriter writer = new com.itextpdf.kernel.pdf.PdfWriter(pdfFile);
            com.itextpdf.kernel.pdf.PdfDocument pdf = new com.itextpdf.kernel.pdf.PdfDocument(writer);
            com.itextpdf.layout.Document document = new com.itextpdf.layout.Document(pdf);

            // Add title
            com.itextpdf.layout.element.Paragraph title = new com.itextpdf.layout.element.Paragraph("Fasty Bites Order Summary")
                    .setFontSize(20)
                    .setBold()
                    .setTextAlignment(com.itextpdf.layout.properties.TextAlignment.CENTER);
            document.add(title);

            document.add(new com.itextpdf.layout.element.Paragraph("\n"));

            // Add customer information
            document.add(new com.itextpdf.layout.element.Paragraph("Customer Information").setBold().setFontSize(14));
            document.add(new com.itextpdf.layout.element.Paragraph("Name: " + name));
            document.add(new com.itextpdf.layout.element.Paragraph("Order Type: " + orderType));
            document.add(new com.itextpdf.layout.element.Paragraph("Address: " + address));
            document.add(new com.itextpdf.layout.element.Paragraph("Payment Method: " + paymentMethod));

            document.add(new com.itextpdf.layout.element.Paragraph("\n"));

            // Add order items
            document.add(new com.itextpdf.layout.element.Paragraph("Order Details").setBold().setFontSize(14));

            if (orderItems != null && !orderItems.isEmpty()) {
                String[] items = orderItems.split(",");
                for (String item : items) {
                    if (!item.trim().isEmpty()) {
                        String[] parts = item.split("\\|");
                        if (parts.length == 3) {
                            String itemName = parts[0];
                            int quantity = Integer.parseInt(parts[1]);
                            double price = Double.parseDouble(parts[2]);
                            double itemTotal = quantity * price;

                            String itemText = String.format("%s\nQuantity: %d x $%.2f = $%.2f\n",
                                    itemName, quantity, price, itemTotal);
                            document.add(new com.itextpdf.layout.element.Paragraph(itemText));
                        }
                    }
                }
            }

            document.add(new com.itextpdf.layout.element.Paragraph("\n"));

            // Add total
            com.itextpdf.layout.element.Paragraph total = new com.itextpdf.layout.element.Paragraph(
                    String.format("Total Bill: $%.2f", totalBill))
                    .setBold()
                    .setFontSize(16);
            document.add(total);

            document.close();

            // Share the PDF
            sharePDFFile(pdfFile);

        } catch (Exception e) {
            e.printStackTrace();
            android.widget.Toast.makeText(this, "Error creating PDF: " + e.getMessage(),
                    android.widget.Toast.LENGTH_LONG).show();
        }
    }

    private void sharePDFFile(java.io.File pdfFile) {
        android.net.Uri pdfUri = androidx.core.content.FileProvider.getUriForFile(
                this,
                getApplicationContext().getPackageName() + ".provider",
                pdfFile);

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("application/pdf");
        shareIntent.putExtra(Intent.EXTRA_STREAM, pdfUri);
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Fasty Bites Order");
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        startActivity(Intent.createChooser(shareIntent, "Share order PDF via"));
    }
}