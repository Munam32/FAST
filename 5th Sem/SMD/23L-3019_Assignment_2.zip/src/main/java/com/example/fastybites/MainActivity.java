package com.example.fastybites;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // UI Components
    private RadioGroup rgOrderType, rgPaymentMethod;
    private RadioButton rbPickup, rbDelivery, rbCash, rbCard;
    private EditText etName, etAddress;
    private TextView tvEstimatedTime;

    // Pizza
    private CheckBox cbPizza;
    private TextView tvQuantityPizza;
    private Button btnIncreasePizza, btnDecreasePizza;
    private int quantityPizza = 1;
    private final double pricePizza = 12.99;

    // Burger
    private CheckBox cbBurger;
    private TextView tvQuantityBurger;
    private Button btnIncreaseBurger, btnDecreaseBurger;
    private int quantityBurger = 1;
    private final double priceBurger = 8.99;

    // Fries
    private CheckBox cbFries;
    private TextView tvQuantityFries;
    private Button btnIncreaseFries, btnDecreaseFries;
    private int quantityFries = 1;
    private final double priceFries = 4.99;

    // Sandwich
    private CheckBox cbSandwich;
    private TextView tvQuantitySandwich;
    private Button btnIncreaseSandwich, btnDecreaseSandwich;
    private int quantitySandwich = 1;
    private final double priceSandwich = 7.99;

    private Button btnOrderNow, btnClear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupListeners();
        setInitialState();
    }

    private void initializeViews() {
        // Order Type and Payment
        rgOrderType = findViewById(R.id.rgOrderType);
        rgPaymentMethod = findViewById(R.id.rgPaymentMethod);
        rbPickup = findViewById(R.id.rbPickup);
        rbDelivery = findViewById(R.id.rbDelivery);
        rbCash = findViewById(R.id.rbCash);
        rbCard = findViewById(R.id.rbCard);

        // Input fields
        etName = findViewById(R.id.etName);
        etAddress = findViewById(R.id.etAddress);
        tvEstimatedTime = findViewById(R.id.tvEstimatedTime);

        // Pizza
        cbPizza = findViewById(R.id.cbPizza);
        tvQuantityPizza = findViewById(R.id.tvQuantityPizza);
        btnIncreasePizza = findViewById(R.id.btnIncreasePizza);
        btnDecreasePizza = findViewById(R.id.btnDecreasePizza);

        // Burger
        cbBurger = findViewById(R.id.cbBurger);
        tvQuantityBurger = findViewById(R.id.tvQuantityBurger);
        btnIncreaseBurger = findViewById(R.id.btnIncreaseBurger);
        btnDecreaseBurger = findViewById(R.id.btnDecreaseBurger);

        // Fries
        cbFries = findViewById(R.id.cbFries);
        tvQuantityFries = findViewById(R.id.tvQuantityFries);
        btnIncreaseFries = findViewById(R.id.btnIncreaseFries);
        btnDecreaseFries = findViewById(R.id.btnDecreaseFries);

        // Sandwich
        cbSandwich = findViewById(R.id.cbSandwich);
        tvQuantitySandwich = findViewById(R.id.tvQuantitySandwich);
        btnIncreaseSandwich = findViewById(R.id.btnIncreaseSandwich);
        btnDecreaseSandwich = findViewById(R.id.btnDecreaseSandwich);

        // Buttons
        btnOrderNow = findViewById(R.id.btnOrderNow);
        btnClear = findViewById(R.id.btnClear);
    }

    private void setInitialState() {
        // Since both radio buttons are unchecked in XML, check pickup by default
        rbPickup.setChecked(true);
        rbCash.setChecked(true);

        // Set address to N/A for pickup
        etAddress.setText("N/A");
        etAddress.setEnabled(false);
        tvEstimatedTime.setText("Estimated Time: 20 mins");

        // Ensure quantities display correctly on start
        tvQuantityPizza.setText(String.valueOf(quantityPizza));
        tvQuantityBurger.setText(String.valueOf(quantityBurger));
        tvQuantityFries.setText(String.valueOf(quantityFries));
        tvQuantitySandwich.setText(String.valueOf(quantitySandwich));
    }

    private void setupListeners() {
        // Order type listener
        rgOrderType.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbPickup) {
                etAddress.setText("N/A");
                etAddress.setEnabled(false);
                tvEstimatedTime.setText("Estimated Time: 20 mins");
            } else if (checkedId == R.id.rbDelivery) {
                etAddress.setText("");
                etAddress.setEnabled(true);
                etAddress.requestFocus();
                tvEstimatedTime.setText("Estimated Time: 30 mins");
            }
        });

        // Pizza quantity buttons
        btnIncreasePizza.setOnClickListener(v -> {
            quantityPizza++;
            tvQuantityPizza.setText(String.valueOf(quantityPizza));
        });

        btnDecreasePizza.setOnClickListener(v -> {
            if (quantityPizza > 1) {
                quantityPizza--;
                tvQuantityPizza.setText(String.valueOf(quantityPizza));
            }
        });

        // Burger quantity buttons
        btnIncreaseBurger.setOnClickListener(v -> {
            quantityBurger++;
            tvQuantityBurger.setText(String.valueOf(quantityBurger));
        });

        btnDecreaseBurger.setOnClickListener(v -> {
            if (quantityBurger > 1) {
                quantityBurger--;
                tvQuantityBurger.setText(String.valueOf(quantityBurger));
            }
        });

        // Fries quantity buttons
        btnIncreaseFries.setOnClickListener(v -> {
            quantityFries++;
            tvQuantityFries.setText(String.valueOf(quantityFries));
        });

        btnDecreaseFries.setOnClickListener(v -> {
            if (quantityFries > 1) {
                quantityFries--;
                tvQuantityFries.setText(String.valueOf(quantityFries));
            }
        });

        // Sandwich quantity buttons
        btnIncreaseSandwich.setOnClickListener(v -> {
            quantitySandwich++;
            tvQuantitySandwich.setText(String.valueOf(quantitySandwich));
        });

        btnDecreaseSandwich.setOnClickListener(v -> {
            if (quantitySandwich > 1) {
                quantitySandwich--;
                tvQuantitySandwich.setText(String.valueOf(quantitySandwich));
            }
        });

        // Clear button
        btnClear.setOnClickListener(v -> showClearConfirmationDialog());

        // Order Now button
        btnOrderNow.setOnClickListener(v -> processOrder());
    }

    private void showClearConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Reset Order")
                .setMessage("Are you sure you want to reset your order?")
                .setPositiveButton("Yes", (dialog, which) -> resetAllFields())
                .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void resetAllFields() {
        // Reset input fields
        etName.setText("");
        etAddress.setText("N/A");
        etAddress.setEnabled(false);

        // Reset to default selections
        rbPickup.setChecked(true);
        rbCash.setChecked(true);

        // Reset checkboxes - all unchecked as per your XML
        cbPizza.setChecked(false);
        cbBurger.setChecked(false);
        cbFries.setChecked(false);
        cbSandwich.setChecked(false);

        // Reset quantities to 1
        quantityPizza = 1;
        quantityBurger = 1;
        quantityFries = 1;
        quantitySandwich = 1;

        tvQuantityPizza.setText("1");
        tvQuantityBurger.setText("1");
        tvQuantityFries.setText("1");
        tvQuantitySandwich.setText("1");

        tvEstimatedTime.setText("Estimated Time: 20 mins");

        Toast.makeText(this, "Order reset successfully", Toast.LENGTH_SHORT).show();
    }

    private void processOrder() {
        // Validation
        String name = etName.getText().toString().trim();
        String address = etAddress.getText().toString().trim();

        if (name.isEmpty()) {
            showErrorDialog("Please enter your name");
            return;
        }

        boolean isDelivery = rbDelivery.isChecked();

        if (isDelivery && address.isEmpty()) {
            showErrorDialog("Please enter delivery address");
            return;
        }

        // Check if at least one item is selected
        if (!cbPizza.isChecked() && !cbBurger.isChecked() &&
                !cbFries.isChecked() && !cbSandwich.isChecked()) {
            showErrorDialog("Please select at least one item");
            return;
        }

        // Check payment method
        if (!rbCash.isChecked() && !rbCard.isChecked()) {
            showErrorDialog("Please select a payment method");
            return;
        }

        // Read current quantities from TextViews to ensure we have latest values
        quantityPizza = Integer.parseInt(tvQuantityPizza.getText().toString());
        quantityBurger = Integer.parseInt(tvQuantityBurger.getText().toString());
        quantityFries = Integer.parseInt(tvQuantityFries.getText().toString());
        quantitySandwich = Integer.parseInt(tvQuantitySandwich.getText().toString());

        // Calculate total bill and build order items string
        double totalBill = 0.0;
        StringBuilder orderItems = new StringBuilder();

        if (cbPizza.isChecked()) {
            double pizzaTotal = pricePizza * quantityPizza;
            totalBill += pizzaTotal;
            orderItems.append("Margherita Pizza|")
                    .append(quantityPizza)
                    .append("|")
                    .append(pricePizza)
                    .append(",");
        }

        if (cbBurger.isChecked()) {
            double burgerTotal = priceBurger * quantityBurger;
            totalBill += burgerTotal;
            orderItems.append("Classic Burger|")
                    .append(quantityBurger)
                    .append("|")
                    .append(priceBurger)
                    .append(",");
        }

        if (cbFries.isChecked()) {
            double friesTotal = priceFries * quantityFries;
            totalBill += friesTotal;
            orderItems.append("Crispy Fries|")
                    .append(quantityFries)
                    .append("|")
                    .append(priceFries)
                    .append(",");
        }

        if (cbSandwich.isChecked()) {
            double sandwichTotal = priceSandwich * quantitySandwich;
            totalBill += sandwichTotal;
            orderItems.append("Club Sandwich|")
                    .append(quantitySandwich)
                    .append("|")
                    .append(priceSandwich)
                    .append(",");
        }

        // Get order type and payment method
        String orderType = isDelivery ? "Delivery" : "Pickup";
        String paymentMethod = rbCard.isChecked() ? "Card" : "Cash";

        // Create intent and pass data to SummaryActivity
        Intent intent = new Intent(MainActivity.this, SummaryActivity.class);
        intent.putExtra("name", name);
        intent.putExtra("orderType", orderType);
        intent.putExtra("address", address);
        intent.putExtra("paymentMethod", paymentMethod);
        intent.putExtra("orderItems", orderItems.toString());
        intent.putExtra("totalBill", totalBill);

        startActivity(intent);
    }

    private void showErrorDialog(String message) {
        new AlertDialog.Builder(this)
                .setTitle("Validation Error")
                .setMessage(message)
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .show();
    }
}