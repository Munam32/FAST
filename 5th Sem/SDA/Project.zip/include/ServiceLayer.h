// ============================================================================
// Service Layer - Business Logic
// Single Responsibility: Each service handles one area of business logic
// Dependency Inversion: Services depend on repository interfaces, not implementations
// Open/Closed: Services are open for extension through inheritance
// ============================================================================

#ifndef SERVICE_LAYER_H
#define SERVICE_LAYER_H

#include "DomainModels.h"
#include "RepositoryInterfaces.h"
#include <memory>
#include <stdexcept>
#include <sstream>

// Academic Officer Service - Manages lab setup and scheduling
class AcademicOfficerService {
private:
    std::shared_ptr<ILabSectionRepository> labRepository;
    std::shared_ptr<IInstructorRepository> instructorRepository;
    std::shared_ptr<ITARepository> taRepository;
    
public:
    AcademicOfficerService(
        std::shared_ptr<ILabSectionRepository> labRepo,
        std::shared_ptr<IInstructorRepository> instrRepo,
        std::shared_ptr<ITARepository> taRepo)
        : labRepository(labRepo), instructorRepository(instrRepo), taRepository(taRepo) {}
    
    // Create a new lab section
    bool createLabSection(const LabSection& lab) {
        // Validate instructor exists
        auto instructor = instructorRepository->findById(lab.getInstructorId());
        if (!instructor) {
            throw std::runtime_error("Instructor not found: " + lab.getInstructorId());
        }
        
        // Validate all TAs exist
        for (const auto& taId : lab.getTAIds()) {
            auto ta = taRepository->findById(taId);
            if (!ta) {
                throw std::runtime_error("TA not found: " + taId);
            }
        }
        
        return labRepository->save(lab);
    }
    
    // Update lab schedule
    bool updateLabSchedule(const std::string& labId, const LabSchedule& newSchedule) {
        auto lab = labRepository->findById(labId);
        if (!lab) {
            throw std::runtime_error("Lab not found: " + labId);
        }
        
        lab->setSchedule(newSchedule);
        return labRepository->update(*lab);
    }
    
    // Assign instructor to lab
    bool assignInstructor(const std::string& labId, const std::string& instructorId) {
        auto lab = labRepository->findById(labId);
        if (!lab) {
            throw std::runtime_error("Lab not found: " + labId);
        }
        
        auto instructor = instructorRepository->findById(instructorId);
        if (!instructor) {
            throw std::runtime_error("Instructor not found: " + instructorId);
        }
        
        lab->setInstructorId(instructorId);
        return labRepository->update(*lab);
    }
    
    // Add TA to lab
    bool addTAToLab(const std::string& labId, const std::string& taId) {
        auto lab = labRepository->findById(labId);
        if (!lab) {
            throw std::runtime_error("Lab not found: " + labId);
        }
        
        auto ta = taRepository->findById(taId);
        if (!ta) {
            throw std::runtime_error("TA not found: " + taId);
        }
        
        lab->addTA(taId);
        return labRepository->update(*lab);
    }
    
    // Remove TA from lab
    bool removeTAFromLab(const std::string& labId, const std::string& taId) {
        auto lab = labRepository->findById(labId);
        if (!lab) {
            throw std::runtime_error("Lab not found: " + labId);
        }
        
        lab->removeTA(taId);
        return labRepository->update(*lab);
    }
    
    // Schedule makeup lab
    bool scheduleMakeupLab(const std::string& originalLabId, const LabSchedule& makeupSchedule,
                          const Date& makeupDate) {
        auto originalLab = labRepository->findById(originalLabId);
        if (!originalLab) {
            throw std::runtime_error("Original lab not found: " + originalLabId);
        }
        
        // Create a new lab section for makeup
        LabSection makeupLab = *originalLab;
        makeupLab.setLabId(originalLabId + "_MAKEUP_" + std::to_string(makeupDate.day) + 
                          std::to_string(makeupDate.month));
        makeupLab.setSchedule(makeupSchedule);
        makeupLab.setIsMakeupLab(true);
        
        return labRepository->save(makeupLab);
    }
};

// Attendant Service - Manages time sheets
class AttendantService {
private:
    std::shared_ptr<ILabSectionRepository> labRepository;
    std::shared_ptr<IAttendantRepository> attendantRepository;
    
    // Helper to validate attendant has access to building
    bool validateBuildingAccess(const std::string& attendantId, const std::string& buildingName) {
        auto attendant = attendantRepository->findById(attendantId);
        if (!attendant) {
            throw std::runtime_error("Attendant not found: " + attendantId);
        }
        
        return attendant->getAssignedBuilding() == buildingName;
    }
    
public:
    AttendantService(
        std::shared_ptr<ILabSectionRepository> labRepo,
        std::shared_ptr<IAttendantRepository> attendantRepo)
        : labRepository(labRepo), attendantRepository(attendantRepo) {}
    
    // Record actual lab session
    bool recordLabSession(const std::string& attendantId, const std::string& labId,
                         const TimeSheetEntry& entry) {
        auto lab = labRepository->findById(labId);
        if (!lab) {
            throw std::runtime_error("Lab not found: " + labId);
        }
        
        // Validate attendant has access to the building
        std::string buildingName = lab->getVenue().getBuildingName();
        if (!validateBuildingAccess(attendantId, buildingName)) {
            throw std::runtime_error("Attendant does not have access to building: " + buildingName);
        }
        
        lab->addTimeSheetEntry(entry);
        return labRepository->update(*lab);
    }
    
    // Mark lab as leave
    bool markLabAsLeave(const std::string& attendantId, const std::string& labId,
                       const Date& date, const std::string& remarks) {
        auto lab = labRepository->findById(labId);
        if (!lab) {
            throw std::runtime_error("Lab not found: " + labId);
        }
        
        // Validate attendant has access to the building
        std::string buildingName = lab->getVenue().getBuildingName();
        if (!validateBuildingAccess(attendantId, buildingName)) {
            throw std::runtime_error("Attendant does not have access to building: " + buildingName);
        }
        
        // Generate entry ID
        std::string entryId = labId + "_LEAVE_" + std::to_string(date.day) + 
                             std::to_string(date.month) + std::to_string(date.year);
        
        TimeSheetEntry leaveEntry(entryId, date, TimeSlot(), true, remarks);
        lab->addTimeSheetEntry(leaveEntry);
        
        return labRepository->update(*lab);
    }
};

// Report Generation Service - Follows Single Responsibility and Open/Closed principles
class ReportGenerationService {
private:
    std::shared_ptr<ILabSectionRepository> labRepository;
    std::shared_ptr<IInstructorRepository> instructorRepository;
    std::shared_ptr<ITARepository> taRepository;
    
    // Helper: Get day name
    std::string getDayName(DayOfWeek day) const {
        switch (day) {
            case DayOfWeek::MONDAY: return "Monday";
            case DayOfWeek::TUESDAY: return "Tuesday";
            case DayOfWeek::WEDNESDAY: return "Wednesday";
            case DayOfWeek::THURSDAY: return "Thursday";
            case DayOfWeek::FRIDAY: return "Friday";
            case DayOfWeek::SATURDAY: return "Saturday";
            case DayOfWeek::SUNDAY: return "Sunday";
            default: return "Unknown";
        }
    }
    
    // Helper: Format time
    std::string formatTime(int hour, int minute) const {
        std::stringstream ss;
        ss << (hour < 10 ? "0" : "") << hour << ":" 
           << (minute < 10 ? "0" : "") << minute;
        return ss.str();
    }
    
    // Helper: Check if date is in week range
    bool isDateInWeek(const Date& date, int weekNumber, int year) const {
        // Simplified week calculation - in production, use proper date library
        // This assumes week 1 starts on Jan 1
        int dayOfYear = date.day + (date.month - 1) * 30; // Approximate
        int calculatedWeek = (dayOfYear / 7) + 1;
        return (calculatedWeek == weekNumber && date.year == year);
    }
    
public:
    ReportGenerationService(
        std::shared_ptr<ILabSectionRepository> labRepo,
        std::shared_ptr<IInstructorRepository> instrRepo,
        std::shared_ptr<ITARepository> taRepo)
        : labRepository(labRepo), instructorRepository(instrRepo), taRepository(taRepo) {}
    
    // Generate complete lab schedule for entire week
    std::string generateWeeklyScheduleReport() {
        std::stringstream report;
        report << "====================================================\n";
        report << "         WEEKLY LAB SCHEDULE REPORT\n";
        report << "====================================================\n\n";
        
        // Iterate through each day of the week
        for (int d = 0; d <= 6; ++d) {
            DayOfWeek day = static_cast<DayOfWeek>(d);
            report << "\n" << getDayName(day) << ":\n";
            report << "----------------------------------------------------\n";
            
            std::vector<LabSection> labs = labRepository->findByDayOfWeek(day);
            
            if (labs.empty()) {
                report << "  No labs scheduled\n";
            } else {
                for (const auto& lab : labs) {
                    LabSchedule schedule = lab.getSchedule();
                    TimeSlot slot = schedule.getTimeSlot();
                    Venue venue = lab.getVenue();
                    
                    auto instructor = instructorRepository->findById(lab.getInstructorId());
                    
                    report << "  " << lab.getCourseCode() << " - " << lab.getLabName() 
                           << " (" << lab.getSectionName() << ")\n";
                    report << "    Time: " << formatTime(slot.startHour, slot.startMinute)
                           << " - " << formatTime(slot.endHour, slot.endMinute) << "\n";
                    report << "    Venue: " << venue.getBuildingName() << " - Room " 
                           << venue.getRoomNumber() << "\n";
                    report << "    Instructor: " << (instructor ? instructor->getName() : "N/A") << "\n";
                    
                    if (!lab.getTAIds().empty()) {
                        report << "    TAs: ";
                        for (size_t i = 0; i < lab.getTAIds().size(); ++i) {
                            auto ta = taRepository->findById(lab.getTAIds()[i]);
                            if (ta) {
                                report << ta->getName();
                                if (i < lab.getTAIds().size() - 1) report << ", ";
                            }
                        }
                        report << "\n";
                    }
                    
                    if (lab.getIsMakeupLab()) {
                        report << "    [MAKEUP LAB]\n";
                    }
                    
                    report << "\n";
                }
            }
        }
        
        return report.str();
    }
    
    // Generate filled time sheet for all labs in a given week
    std::string generateWeeklyTimeSheetReport(int weekNumber, int year) {
        std::stringstream report;
        report << "====================================================\n";
        report << "    TIME SHEET REPORT - Week " << weekNumber << ", " << year << "\n";
        report << "====================================================\n\n";
        
        std::vector<LabSection> allLabs = labRepository->findAll();
        
        for (const auto& lab : allLabs) {
            bool hasEntriesThisWeek = false;
            std::vector<TimeSheetEntry> entries = lab.getTimeSheetEntries();
            
            // Check if lab has entries in this week
            for (const auto& entry : entries) {
                if (isDateInWeek(entry.getDate(), weekNumber, year)) {
                    hasEntriesThisWeek = true;
                    break;
                }
            }
            
            if (!hasEntriesThisWeek) continue;
            
            report << lab.getCourseCode() << " - " << lab.getLabName() 
                   << " (" << lab.getSectionName() << ")\n";
            report << "----------------------------------------------------\n";
            
            for (const auto& entry : entries) {
                if (isDateInWeek(entry.getDate(), weekNumber, year)) {
                    Date date = entry.getDate();
                    report << "  Date: " << date.day << "/" << date.month << "/" << date.year << "\n";
                    
                    if (entry.getIsLeave()) {
                        report << "    Status: LEAVE\n";
                        report << "    Remarks: " << entry.getRemarks() << "\n";
                    } else {
                        TimeSlot slot = entry.getActualTimeSlot();
                        report << "    Start Time: " << formatTime(slot.startHour, slot.startMinute) << "\n";
                        report << "    End Time: " << formatTime(slot.endHour, slot.endMinute) << "\n";
                        report << "    Duration: " << slot.getDurationInHours() << " hours\n";
                        if (!entry.getRemarks().empty()) {
                            report << "    Remarks: " << entry.getRemarks() << "\n";
                        }
                    }
                    report << "\n";
                }
            }
            report << "\n";
        }
        
        return report.str();
    }
    
    // Generate time sheet for all sessions of a particular lab (semester report)
    std::string generateLabSemesterReport(const std::string& labId) {
        auto lab = labRepository->findById(labId);
        if (!lab) {
            throw std::runtime_error("Lab not found: " + labId);
        }
        
        std::stringstream report;
        report << "====================================================\n";
        report << "         SEMESTER REPORT FOR LAB\n";
        report << "====================================================\n\n";
        
        report << "Course: " << lab->getCourseCode() << " - " << lab->getLabName() << "\n";
        report << "Section: " << lab->getSectionName() << "\n";
        
        auto instructor = instructorRepository->findById(lab->getInstructorId());
        report << "Instructor: " << (instructor ? instructor->getName() : "N/A") << "\n\n";
        
        report << "----------------------------------------------------\n";
        report << "SESSION DETAILS:\n";
        report << "----------------------------------------------------\n\n";
        
        std::vector<TimeSheetEntry> entries = lab->getTimeSheetEntries();
        
        if (entries.empty()) {
            report << "No sessions recorded.\n";
        } else {
            for (const auto& entry : entries) {
                Date date = entry.getDate();
                report << "Date: " << date.day << "/" << date.month << "/" << date.year << "\n";
                
                if (entry.getIsLeave()) {
                    report << "  Status: LEAVE\n";
                    report << "  Remarks: " << entry.getRemarks() << "\n";
                } else {
                    TimeSlot slot = entry.getActualTimeSlot();
                    report << "  Time: " << formatTime(slot.startHour, slot.startMinute)
                           << " - " << formatTime(slot.endHour, slot.endMinute) << "\n";
                    report << "  Duration: " << slot.getDurationInHours() << " hours\n";
                }
                report << "\n";
            }
        }
        
        report << "----------------------------------------------------\n";
        report << "SUMMARY:\n";
        report << "----------------------------------------------------\n";
        report << "Total Contact Hours: " << lab->getTotalContactHours() << " hours\n";
        report << "Total Leaves: " << lab->getTotalLeaves() << "\n";
        report << "Total Sessions: " << entries.size() << "\n";
        
        return report.str();
    }
};

// Instructor Service - Handles instructor-specific operations
class InstructorService {
private:
    std::shared_ptr<ILabSectionRepository> labRepository;
    std::shared_ptr<IInstructorRepository> instructorRepository;
    
public:
    InstructorService(
        std::shared_ptr<ILabSectionRepository> labRepo,
        std::shared_ptr<IInstructorRepository> instrRepo)
        : labRepository(labRepo), instructorRepository(instrRepo) {}
    
    // Request makeup lab - creates a makeup lab request
    bool requestMakeupLab(const std::string& instructorId, const std::string& labId,
                         const LabSchedule& proposedSchedule, const Date& makeupDate,
                         const std::string& reason) {
        // Verify instructor exists
        auto instructor = instructorRepository->findById(instructorId);
        if (!instructor) {
            throw std::runtime_error("Instructor not found: " + instructorId);
        }
        
        // Verify instructor owns this lab
        auto lab = labRepository->findById(labId);
        if (!lab) {
            throw std::runtime_error("Lab not found: " + labId);
        }
        
        if (lab->getInstructorId() != instructorId) {
            throw std::runtime_error("Instructor does not own this lab");
        }
        
        // Create makeup lab directly (instructor has permission to request)
        // Note: reason parameter could be stored in lab remarks for future enhancement
        (void)reason; // Suppress unused parameter warning
        
        LabSection makeupLab = *lab;
        makeupLab.setLabId(labId + "_MAKEUP_" + std::to_string(makeupDate.day) + 
                          std::to_string(makeupDate.month) + std::to_string(makeupDate.year));
        makeupLab.setSchedule(proposedSchedule);
        makeupLab.setIsMakeupLab(true);
        
        return labRepository->save(makeupLab);
    }
    
    // Get labs taught by instructor
    std::vector<LabSection> getMyLabs(const std::string& instructorId) {
        return labRepository->findByInstructor(instructorId);
    }
};

#endif // SERVICE_LAYER_H