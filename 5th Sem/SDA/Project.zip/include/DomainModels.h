// ============================================================================
// Domain Models - High Cohesion: Each class has a single, well-defined purpose
// ============================================================================

#ifndef DOMAIN_MODELS_H
#define DOMAIN_MODELS_H

#include <string>
#include <vector>
#include <ctime>
#include <algorithm>  // for std::find

// Value Objects - Immutable data structures
struct TimeSlot {
    int startHour;
    int startMinute;
    int endHour;
    int endMinute;
    
    TimeSlot(int sh = 0, int sm = 0, int eh = 0, int em = 0)
        : startHour(sh), startMinute(sm), endHour(eh), endMinute(em) {}
    
    double getDurationInHours() const {
        return ((endHour * 60 + endMinute) - (startHour * 60 + startMinute)) / 60.0;
    }
};

struct Date {
    int day;
    int month;
    int year;
    
    Date(int d = 1, int m = 1, int y = 2024)
        : day(d), month(m), year(y) {}
    
    bool operator==(const Date& other) const {
        return day == other.day && month == other.month && year == other.year;
    }
};

enum class DayOfWeek {
    MONDAY = 0, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
};

// Entity: Venue (Building and Room)
class Venue {
private:
    std::string buildingName;
    std::string roomNumber;
    int capacity;
    
public:
    Venue(const std::string& building = "", const std::string& room = "", int cap = 0)
        : buildingName(building), roomNumber(room), capacity(cap) {}
    
    std::string getBuildingName() const { return buildingName; }
    std::string getRoomNumber() const { return roomNumber; }
    int getCapacity() const { return capacity; }
    
    void setBuildingName(const std::string& name) { buildingName = name; }
    void setRoomNumber(const std::string& room) { roomNumber = room; }
    void setCapacity(int cap) { capacity = cap; }
};

// Entity: Person (Base class following OCP - Open for extension)
class Person {
protected:
    std::string id;
    std::string name;
    std::string email;
    std::string phoneNumber;
    
public:
    Person(const std::string& personId = "", const std::string& personName = "",
           const std::string& personEmail = "", const std::string& phone = "")
        : id(personId), name(personName), email(personEmail), phoneNumber(phone) {}
    
    virtual ~Person() = default;
    
    std::string getId() const { return id; }
    std::string getName() const { return name; }
    std::string getEmail() const { return email; }
    std::string getPhoneNumber() const { return phoneNumber; }
    
    void setId(const std::string& personId) { id = personId; }
    void setName(const std::string& personName) { name = personName; }
    void setEmail(const std::string& personEmail) { email = personEmail; }
    void setPhoneNumber(const std::string& phone) { phoneNumber = phone; }
};

// Derived Entities - Following LSP (Liskov Substitution Principle)
class Instructor : public Person {
private:
    std::string department;
    std::string designation;
    
public:
    Instructor(const std::string& id = "", const std::string& name = "",
               const std::string& email = "", const std::string& phone = "",
               const std::string& dept = "", const std::string& desig = "")
        : Person(id, name, email, phone), department(dept), designation(desig) {}
    
    std::string getDepartment() const { return department; }
    std::string getDesignation() const { return designation; }
    
    void setDepartment(const std::string& dept) { department = dept; }
    void setDesignation(const std::string& desig) { designation = desig; }
};

class TeachingAssistant : public Person {
private:
    std::string studentId;
    std::string program;
    
public:
    TeachingAssistant(const std::string& id = "", const std::string& name = "",
                      const std::string& email = "", const std::string& phone = "",
                      const std::string& studId = "", const std::string& prog = "")
        : Person(id, name, email, phone), studentId(studId), program(prog) {}
    
    std::string getStudentId() const { return studentId; }
    std::string getProgram() const { return program; }
    
    void setStudentId(const std::string& studId) { studentId = studId; }
    void setProgram(const std::string& prog) { program = prog; }
};

class Attendant : public Person {
private:
    std::string assignedBuilding;
    
public:
    Attendant(const std::string& id = "", const std::string& name = "",
              const std::string& email = "", const std::string& phone = "",
              const std::string& building = "")
        : Person(id, name, email, phone), assignedBuilding(building) {}
    
    std::string getAssignedBuilding() const { return assignedBuilding; }
    void setAssignedBuilding(const std::string& building) { assignedBuilding = building; }
};

// Entity: Lab Schedule (Expected timings)
class LabSchedule {
private:
    std::string scheduleId;
    DayOfWeek dayOfWeek;
    TimeSlot timeSlot;
    
public:
    LabSchedule(const std::string& id = "", DayOfWeek day = DayOfWeek::MONDAY,
                const TimeSlot& slot = TimeSlot())
        : scheduleId(id), dayOfWeek(day), timeSlot(slot) {}
    
    std::string getScheduleId() const { return scheduleId; }
    DayOfWeek getDayOfWeek() const { return dayOfWeek; }
    TimeSlot getTimeSlot() const { return timeSlot; }
    
    void setScheduleId(const std::string& id) { scheduleId = id; }
    void setDayOfWeek(DayOfWeek day) { dayOfWeek = day; }
    void setTimeSlot(const TimeSlot& slot) { timeSlot = slot; }
};

// Entity: Time Sheet Entry (Actual timings)
class TimeSheetEntry {
private:
    std::string entryId;
    Date date;
    TimeSlot actualTimeSlot;
    bool isLeave;
    std::string remarks;
    
public:
    TimeSheetEntry(const std::string& id = "", const Date& entryDate = Date(),
                   const TimeSlot& slot = TimeSlot(), bool leave = false,
                   const std::string& rem = "")
        : entryId(id), date(entryDate), actualTimeSlot(slot), isLeave(leave), remarks(rem) {}
    
    std::string getEntryId() const { return entryId; }
    Date getDate() const { return date; }
    TimeSlot getActualTimeSlot() const { return actualTimeSlot; }
    bool getIsLeave() const { return isLeave; }
    std::string getRemarks() const { return remarks; }
    
    void setEntryId(const std::string& id) { entryId = id; }
    void setDate(const Date& entryDate) { date = entryDate; }
    void setActualTimeSlot(const TimeSlot& slot) { actualTimeSlot = slot; }
    void setIsLeave(bool leave) { isLeave = leave; }
    void setRemarks(const std::string& rem) { remarks = rem; }
};

// Aggregate Root: Lab Section
class LabSection {
private:
    std::string labId;
    std::string labName;
    std::string courseCode;
    std::string sectionName;
    Venue venue;
    std::string instructorId;
    std::vector<std::string> taIds;
    LabSchedule schedule;
    std::vector<TimeSheetEntry> timeSheetEntries;
    bool isMakeupLab;
    
public:
    LabSection(const std::string& id = "", const std::string& name = "",
               const std::string& code = "", const std::string& section = "")
        : labId(id), labName(name), courseCode(code), sectionName(section), 
          isMakeupLab(false) {}
    
    // Getters
    std::string getLabId() const { return labId; }
    std::string getLabName() const { return labName; }
    std::string getCourseCode() const { return courseCode; }
    std::string getSectionName() const { return sectionName; }
    Venue getVenue() const { return venue; }
    std::string getInstructorId() const { return instructorId; }
    std::vector<std::string> getTAIds() const { return taIds; }
    LabSchedule getSchedule() const { return schedule; }
    std::vector<TimeSheetEntry> getTimeSheetEntries() const { return timeSheetEntries; }
    bool getIsMakeupLab() const { return isMakeupLab; }
    
    // Setters
    void setLabId(const std::string& id) { labId = id; }
    void setLabName(const std::string& name) { labName = name; }
    void setCourseCode(const std::string& code) { courseCode = code; }
    void setSectionName(const std::string& section) { sectionName = section; }
    void setVenue(const Venue& v) { venue = v; }
    void setInstructorId(const std::string& id) { instructorId = id; }
    void setSchedule(const LabSchedule& sched) { schedule = sched; }
    void setIsMakeupLab(bool makeup) { isMakeupLab = makeup; }
    
    // Business logic
    void addTA(const std::string& taId) { taIds.push_back(taId); }
    void removeTA(const std::string& taId) {
        auto it = std::find(taIds.begin(), taIds.end(), taId);
        if (it != taIds.end()) {
            taIds.erase(it);
        }
    }
    
    void addTimeSheetEntry(const TimeSheetEntry& entry) {
        timeSheetEntries.push_back(entry);
    }
    
    double getTotalContactHours() const {
        double total = 0.0;
        for (const auto& entry : timeSheetEntries) {
            if (!entry.getIsLeave()) {
                total += entry.getActualTimeSlot().getDurationInHours();
            }
        }
        return total;
    }
    
    int getTotalLeaves() const {
        int count = 0;
        for (const auto& entry : timeSheetEntries) {
            if (entry.getIsLeave()) {
                count++;
            }
        }
        return count;
    }
};

#endif // DOMAIN_MODELS_H