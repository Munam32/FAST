// ============================================================================
// Binary File Repository Implementations
// Low Coupling: Repositories only depend on domain models and interfaces
// Single Responsibility: Each repository manages persistence for one entity
// ============================================================================

#ifndef BINARY_REPOSITORIES_H
#define BINARY_REPOSITORIES_H

#include "RepositoryInterfaces.h"
#include <fstream>
#include <iostream>
#include <algorithm>
#include <cstring>

// Helper class for binary serialization (Single Responsibility)
class BinarySerializer {
public:
    // String serialization
    static void writeString(std::ofstream& ofs, const std::string& str) {
        size_t length = str.length();
        ofs.write(reinterpret_cast<const char*>(&length), sizeof(length));
        ofs.write(str.c_str(), length);
    }

    static std::string readString(std::ifstream& ifs) {
        size_t length;
        ifs.read(reinterpret_cast<char*>(&length), sizeof(length));
        char* buffer = new char[length + 1];
        ifs.read(buffer, length);
        buffer[length] = '\0';
        std::string result(buffer);
        delete[] buffer;
        return result;
    }

    // Vector of strings serialization
    static void writeStringVector(std::ofstream& ofs, const std::vector<std::string>& vec) {
        size_t size = vec.size();
        ofs.write(reinterpret_cast<const char*>(&size), sizeof(size));
        for (const auto& str : vec) {
            writeString(ofs, str);
        }
    }

    static std::vector<std::string> readStringVector(std::ifstream& ifs) {
        size_t size;
        ifs.read(reinterpret_cast<char*>(&size), sizeof(size));
        std::vector<std::string> vec;
        for (size_t i = 0; i < size; ++i) {
            vec.push_back(readString(ifs));
        }
        return vec;
    }
};

// Lab Section Binary Repository
class LabSectionBinaryRepository : public ILabSectionRepository {
private:
    std::string filename;

    void writeLabSection(std::ofstream& ofs, const LabSection& lab) {
        BinarySerializer::writeString(ofs, lab.getLabId());
        BinarySerializer::writeString(ofs, lab.getLabName());
        BinarySerializer::writeString(ofs, lab.getCourseCode());
        BinarySerializer::writeString(ofs, lab.getSectionName());

        // Venue
        Venue venue = lab.getVenue();
        BinarySerializer::writeString(ofs, venue.getBuildingName());
        BinarySerializer::writeString(ofs, venue.getRoomNumber());
        int capacity = venue.getCapacity();
        ofs.write(reinterpret_cast<const char*>(&capacity), sizeof(capacity));

        // Instructor and TAs
        BinarySerializer::writeString(ofs, lab.getInstructorId());
        BinarySerializer::writeStringVector(ofs, lab.getTAIds());

        // Schedule
        LabSchedule schedule = lab.getSchedule();
        BinarySerializer::writeString(ofs, schedule.getScheduleId());
        DayOfWeek day = schedule.getDayOfWeek();
        ofs.write(reinterpret_cast<const char*>(&day), sizeof(day));

        TimeSlot slot = schedule.getTimeSlot();
        ofs.write(reinterpret_cast<const char*>(&slot.startHour), sizeof(slot.startHour));
        ofs.write(reinterpret_cast<const char*>(&slot.startMinute), sizeof(slot.startMinute));
        ofs.write(reinterpret_cast<const char*>(&slot.endHour), sizeof(slot.endHour));
        ofs.write(reinterpret_cast<const char*>(&slot.endMinute), sizeof(slot.endMinute));

        // TimeSheet Entries
        std::vector<TimeSheetEntry> entries = lab.getTimeSheetEntries();
        size_t entryCount = entries.size();
        ofs.write(reinterpret_cast<const char*>(&entryCount), sizeof(entryCount));

        for (const auto& entry : entries) {
            BinarySerializer::writeString(ofs, entry.getEntryId());

            Date date = entry.getDate();
            ofs.write(reinterpret_cast<const char*>(&date.day), sizeof(date.day));
            ofs.write(reinterpret_cast<const char*>(&date.month), sizeof(date.month));
            ofs.write(reinterpret_cast<const char*>(&date.year), sizeof(date.year));

            TimeSlot actualSlot = entry.getActualTimeSlot();
            ofs.write(reinterpret_cast<const char*>(&actualSlot.startHour), sizeof(actualSlot.startHour));
            ofs.write(reinterpret_cast<const char*>(&actualSlot.startMinute), sizeof(actualSlot.startMinute));
            ofs.write(reinterpret_cast<const char*>(&actualSlot.endHour), sizeof(actualSlot.endHour));
            ofs.write(reinterpret_cast<const char*>(&actualSlot.endMinute), sizeof(actualSlot.endMinute));

            bool isLeave = entry.getIsLeave();
            ofs.write(reinterpret_cast<const char*>(&isLeave), sizeof(isLeave));

            BinarySerializer::writeString(ofs, entry.getRemarks());
        }

        // Makeup lab flag
        bool isMakeup = lab.getIsMakeupLab();
        ofs.write(reinterpret_cast<const char*>(&isMakeup), sizeof(isMakeup));
    }

    LabSection readLabSection(std::ifstream& ifs) {
        LabSection lab;

        lab.setLabId(BinarySerializer::readString(ifs));
        lab.setLabName(BinarySerializer::readString(ifs));
        lab.setCourseCode(BinarySerializer::readString(ifs));
        lab.setSectionName(BinarySerializer::readString(ifs));

        // Venue
        std::string buildingName = BinarySerializer::readString(ifs);
        std::string roomNumber = BinarySerializer::readString(ifs);
        int capacity;
        ifs.read(reinterpret_cast<char*>(&capacity), sizeof(capacity));
        lab.setVenue(Venue(buildingName, roomNumber, capacity));

        // Instructor and TAs
        lab.setInstructorId(BinarySerializer::readString(ifs));
        std::vector<std::string> taIds = BinarySerializer::readStringVector(ifs);
        for (const auto& taId : taIds) {
            lab.addTA(taId);
        }

        // Schedule
        std::string scheduleId = BinarySerializer::readString(ifs);
        DayOfWeek day;
        ifs.read(reinterpret_cast<char*>(&day), sizeof(day));

        TimeSlot slot;
        ifs.read(reinterpret_cast<char*>(&slot.startHour), sizeof(slot.startHour));
        ifs.read(reinterpret_cast<char*>(&slot.startMinute), sizeof(slot.startMinute));
        ifs.read(reinterpret_cast<char*>(&slot.endHour), sizeof(slot.endHour));
        ifs.read(reinterpret_cast<char*>(&slot.endMinute), sizeof(slot.endMinute));

        lab.setSchedule(LabSchedule(scheduleId, day, slot));

        // TimeSheet Entries
        size_t entryCount;
        ifs.read(reinterpret_cast<char*>(&entryCount), sizeof(entryCount));

        for (size_t i = 0; i < entryCount; ++i) {
            std::string entryId = BinarySerializer::readString(ifs);

            Date date;
            ifs.read(reinterpret_cast<char*>(&date.day), sizeof(date.day));
            ifs.read(reinterpret_cast<char*>(&date.month), sizeof(date.month));
            ifs.read(reinterpret_cast<char*>(&date.year), sizeof(date.year));

            TimeSlot actualSlot;
            ifs.read(reinterpret_cast<char*>(&actualSlot.startHour), sizeof(actualSlot.startHour));
            ifs.read(reinterpret_cast<char*>(&actualSlot.startMinute), sizeof(actualSlot.startMinute));
            ifs.read(reinterpret_cast<char*>(&actualSlot.endHour), sizeof(actualSlot.endHour));
            ifs.read(reinterpret_cast<char*>(&actualSlot.endMinute), sizeof(actualSlot.endMinute));

            bool isLeave;
            ifs.read(reinterpret_cast<char*>(&isLeave), sizeof(isLeave));

            std::string remarks = BinarySerializer::readString(ifs);

            lab.addTimeSheetEntry(TimeSheetEntry(entryId, date, actualSlot, isLeave, remarks));
        }

        // Makeup lab flag
        bool isMakeup;
        ifs.read(reinterpret_cast<char*>(&isMakeup), sizeof(isMakeup));
        lab.setIsMakeupLab(isMakeup);

        return lab;
    }

public:
    LabSectionBinaryRepository(const std::string& file = "labs.dat")
        : filename(file) {
    }

    bool save(const LabSection& lab) override {
        std::vector<LabSection> labs = findAll();
        labs.push_back(lab);

        std::ofstream ofs(filename, std::ios::binary | std::ios::trunc);
        if (!ofs) return false;

        size_t count = labs.size();
        ofs.write(reinterpret_cast<const char*>(&count), sizeof(count));

        for (const auto& l : labs) {
            writeLabSection(ofs, l);
        }

        ofs.close();
        return true;
    }

    bool update(const LabSection& lab) override {
        std::vector<LabSection> labs = findAll();
        auto it = std::find_if(labs.begin(), labs.end(),
            [&lab](const LabSection& l) { return l.getLabId() == lab.getLabId(); });

        if (it == labs.end()) return false;

        *it = lab;

        std::ofstream ofs(filename, std::ios::binary | std::ios::trunc);
        if (!ofs) return false;

        size_t count = labs.size();
        ofs.write(reinterpret_cast<const char*>(&count), sizeof(count));

        for (const auto& l : labs) {
            writeLabSection(ofs, l);
        }

        ofs.close();
        return true;
    }

    bool remove(const std::string& id) override {
        std::vector<LabSection> labs = findAll();
        auto it = std::remove_if(labs.begin(), labs.end(),
            [&id](const LabSection& l) { return l.getLabId() == id; });

        if (it == labs.end()) return false;

        labs.erase(it, labs.end());

        std::ofstream ofs(filename, std::ios::binary | std::ios::trunc);
        if (!ofs) return false;

        size_t count = labs.size();
        ofs.write(reinterpret_cast<const char*>(&count), sizeof(count));

        for (const auto& l : labs) {
            writeLabSection(ofs, l);
        }

        ofs.close();
        return true;
    }

    std::unique_ptr<LabSection> findById(const std::string& id) override {
        std::vector<LabSection> labs = findAll();
        auto it = std::find_if(labs.begin(), labs.end(),
            [&id](const LabSection& l) { return l.getLabId() == id; });

        if (it == labs.end()) return nullptr;

        return std::make_unique<LabSection>(*it);
    }

    std::vector<LabSection> findAll() override {
        std::vector<LabSection> labs;
        std::ifstream ifs(filename, std::ios::binary);

        if (!ifs) return labs;

        size_t count;
        ifs.read(reinterpret_cast<char*>(&count), sizeof(count));

        for (size_t i = 0; i < count; ++i) {
            labs.push_back(readLabSection(ifs));
        }

        ifs.close();
        return labs;
    }

    std::vector<LabSection> findByCourseCode(const std::string& courseCode) override {
        std::vector<LabSection> labs = findAll();
        std::vector<LabSection> result;

        std::copy_if(labs.begin(), labs.end(), std::back_inserter(result),
            [&courseCode](const LabSection& l) { return l.getCourseCode() == courseCode; });

        return result;
    }

    std::vector<LabSection> findByInstructor(const std::string& instructorId) override {
        std::vector<LabSection> labs = findAll();
        std::vector<LabSection> result;

        std::copy_if(labs.begin(), labs.end(), std::back_inserter(result),
            [&instructorId](const LabSection& l) { return l.getInstructorId() == instructorId; });

        return result;
    }

    std::vector<LabSection> findByBuilding(const std::string& buildingName) override {
        std::vector<LabSection> labs = findAll();
        std::vector<LabSection> result;

        std::copy_if(labs.begin(), labs.end(), std::back_inserter(result),
            [&buildingName](const LabSection& l) {
                return l.getVenue().getBuildingName() == buildingName;
            });

        return result;
    }

    std::vector<LabSection> findByDayOfWeek(DayOfWeek day) override {
        std::vector<LabSection> labs = findAll();
        std::vector<LabSection> result;

        std::copy_if(labs.begin(), labs.end(), std::back_inserter(result),
            [day](const LabSection& l) {
                return l.getSchedule().getDayOfWeek() == day;
            });

        return result;
    }
};

// Similar implementations for Instructor, TA, and Attendant repositories
// Following the same pattern for consistency and maintainability

class InstructorBinaryRepository : public IInstructorRepository {
private:
    std::string filename;

    void writeInstructor(std::ofstream& ofs, const Instructor& instructor) {
        BinarySerializer::writeString(ofs, instructor.getId());
        BinarySerializer::writeString(ofs, instructor.getName());
        BinarySerializer::writeString(ofs, instructor.getEmail());
        BinarySerializer::writeString(ofs, instructor.getPhoneNumber());
        BinarySerializer::writeString(ofs, instructor.getDepartment());
        BinarySerializer::writeString(ofs, instructor.getDesignation());
    }

    Instructor readInstructor(std::ifstream& ifs) {
        std::string id = BinarySerializer::readString(ifs);
        std::string name = BinarySerializer::readString(ifs);
        std::string email = BinarySerializer::readString(ifs);
        std::string phone = BinarySerializer::readString(ifs);
        std::string dept = BinarySerializer::readString(ifs);
        std::string desig = BinarySerializer::readString(ifs);

        return Instructor(id, name, email, phone, dept, desig);
    }

public:
    InstructorBinaryRepository(const std::string& file = "instructors.dat")
        : filename(file) {
    }

    bool save(const Instructor& instructor) override {
        std::vector<Instructor> instructors = findAll();
        instructors.push_back(instructor);

        std::ofstream ofs(filename, std::ios::binary | std::ios::trunc);
        if (!ofs) return false;

        size_t count = instructors.size();
        ofs.write(reinterpret_cast<const char*>(&count), sizeof(count));

        for (const auto& i : instructors) {
            writeInstructor(ofs, i);
        }

        ofs.close();
        return true;
    }

    bool update(const Instructor& instructor) override {
        std::vector<Instructor> instructors = findAll();
        auto it = std::find_if(instructors.begin(), instructors.end(),
            [&instructor](const Instructor& i) { return i.getId() == instructor.getId(); });

        if (it == instructors.end()) return false;

        *it = instructor;

        std::ofstream ofs(filename, std::ios::binary | std::ios::trunc);
        if (!ofs) return false;

        size_t count = instructors.size();
        ofs.write(reinterpret_cast<const char*>(&count), sizeof(count));

        for (const auto& i : instructors) {
            writeInstructor(ofs, i);
        }

        ofs.close();
        return true;
    }

    bool remove(const std::string& id) override {
        std::vector<Instructor> instructors = findAll();
        auto initialSize = instructors.size();

        instructors.erase(
            std::remove_if(instructors.begin(), instructors.end(),
                [&id](const Instructor& i) { return i.getId() == id; }),
            instructors.end()
        );

        if (instructors.size() == initialSize) return false;

        std::ofstream ofs(filename, std::ios::binary | std::ios::trunc);
        if (!ofs) return false;

        size_t count = instructors.size();
        ofs.write(reinterpret_cast<const char*>(&count), sizeof(count));

        for (const auto& i : instructors) {
            writeInstructor(ofs, i);
        }

        ofs.close();
        return true;
    }

    std::unique_ptr<Instructor> findById(const std::string& id) override {
        std::vector<Instructor> instructors = findAll();
        auto it = std::find_if(instructors.begin(), instructors.end(),
            [&id](const Instructor& i) { return i.getId() == id; });

        if (it == instructors.end()) return nullptr;

        return std::make_unique<Instructor>(*it);
    }

    std::vector<Instructor> findAll() override {
        std::vector<Instructor> instructors;
        std::ifstream ifs(filename, std::ios::binary);

        if (!ifs) return instructors;

        size_t count;
        ifs.read(reinterpret_cast<char*>(&count), sizeof(count));

        for (size_t i = 0; i < count; ++i) {
            instructors.push_back(readInstructor(ifs));
        }

        ifs.close();
        return instructors;
    }

    std::vector<Instructor> findByDepartment(const std::string& department) override {
        std::vector<Instructor> instructors = findAll();
        std::vector<Instructor> result;

        std::copy_if(instructors.begin(), instructors.end(), std::back_inserter(result),
            [&department](const Instructor& i) { return i.getDepartment() == department; });

        return result;
    }
};

#endif // BINARY_REPOSITORIES_H