// ============================================================================
// Repository Interfaces - Following Dependency Inversion Principle (DIP)
// High-level modules depend on abstractions, not concrete implementations
// Interface Segregation Principle (ISP) - Clients depend only on methods they use
// ============================================================================

#ifndef REPOSITORY_INTERFACES_H
#define REPOSITORY_INTERFACES_H

#include "DomainModels.h"
#include <vector>
#include <memory>

// ISP: Separate interfaces for different repository operations

// Generic Repository Interface
template<typename T>
class IRepository {
public:
    virtual ~IRepository() = default;

    virtual bool save(const T& entity) = 0;
    virtual bool update(const T& entity) = 0;
    virtual bool remove(const std::string& id) = 0;
    virtual std::unique_ptr<T> findById(const std::string& id) = 0;
    virtual std::vector<T> findAll() = 0;
};

// Lab Section Repository Interface
class ILabSectionRepository : public IRepository<LabSection> {
public:
    virtual ~ILabSectionRepository() = default;

    // Additional domain-specific queries
    virtual std::vector<LabSection> findByCourseCode(const std::string& courseCode) = 0;
    virtual std::vector<LabSection> findByInstructor(const std::string& instructorId) = 0;
    virtual std::vector<LabSection> findByBuilding(const std::string& buildingName) = 0;
    virtual std::vector<LabSection> findByDayOfWeek(DayOfWeek day) = 0;
};

// Instructor Repository Interface
class IInstructorRepository : public IRepository<Instructor> {
public:
    virtual ~IInstructorRepository() = default;

    virtual std::vector<Instructor> findByDepartment(const std::string& department) = 0;
};

// TA Repository Interface
class ITARepository : public IRepository<TeachingAssistant> {
public:
    virtual ~ITARepository() = default;

    virtual std::vector<TeachingAssistant> findByProgram(const std::string& program) = 0;
};

// Attendant Repository Interface
class IAttendantRepository : public IRepository<Attendant> {
public:
    virtual ~IAttendantRepository() = default;

    virtual std::unique_ptr<Attendant> findByBuilding(const std::string& buildingName) = 0;
};

#endif // REPOSITORY_INTERFACES_H