// ============================================================================
// User Authentication & Management System - FIXED VERSION
// Implements secure login, registration, and role-based access control
// ============================================================================

#ifndef USER_AUTHENTICATION_H
#define USER_AUTHENTICATION_H

#include <string>
#include <vector>
#include <ctime>
#include <algorithm>
#include <memory>
#include <fstream>
#include <cctype>
#include <cstring>

// Enumeration for user roles
enum class UserRole {
    ACADEMIC_OFFICER,
    ATTENDANT,
    INSTRUCTOR,
    HEAD_OF_DEPARTMENT,
    NONE
};

// User entity class
class User {
private:
    std::string userId;
    std::string username;
    std::string password;
    std::string fullName;
    std::string email;
    UserRole role;
    std::string linkedEntityId;
    bool isActive;
    time_t createdAt;
    time_t lastLogin;
    
public:
    User() : role(UserRole::NONE), isActive(true), createdAt(0), lastLogin(0) {}
    
    User(const std::string& uid, const std::string& uname, const std::string& pwd,
         const std::string& fname, const std::string& em, UserRole r, 
         const std::string& entityId = "")
        : userId(uid), username(uname), password(pwd), fullName(fname),
          email(em), role(r), linkedEntityId(entityId), isActive(true) {
        createdAt = std::time(nullptr);
        lastLogin = 0;
    }
    
    // Getters
    std::string getUserId() const { return userId; }
    std::string getUsername() const { return username; }
    std::string getPassword() const { return password; }
    std::string getFullName() const { return fullName; }
    std::string getEmail() const { return email; }
    UserRole getRole() const { return role; }
    std::string getLinkedEntityId() const { return linkedEntityId; }
    bool getIsActive() const { return isActive; }
    time_t getCreatedAt() const { return createdAt; }
    time_t getLastLogin() const { return lastLogin; }
    
    // Setters
    void setUserId(const std::string& uid) { userId = uid; }
    void setUsername(const std::string& uname) { username = uname; }
    void setPassword(const std::string& pwd) { password = pwd; }
    void setFullName(const std::string& fname) { fullName = fname; }
    void setEmail(const std::string& em) { email = em; }
    void setRole(UserRole r) { role = r; }
    void setLinkedEntityId(const std::string& entityId) { linkedEntityId = entityId; }
    void setIsActive(bool active) { isActive = active; }
    void setCreatedAt(time_t t) { createdAt = t; }
    void setLastLogin(time_t t) { lastLogin = t; }
    
    // Update last login
    void updateLastLogin() {
        lastLogin = std::time(nullptr);
    }
    
    // Verify password
    bool verifyPassword(const std::string& pwd) const {
        return password == pwd;
    }
    
    // Get role as string
    std::string getRoleString() const {
        switch(role) {
            case UserRole::ACADEMIC_OFFICER: return "Academic Officer";
            case UserRole::ATTENDANT: return "Attendant";
            case UserRole::INSTRUCTOR: return "Instructor";
            case UserRole::HEAD_OF_DEPARTMENT: return "Head of Department";
            default: return "Unknown";
        }
    }
};

// User Repository Interface
class IUserRepository {
public:
    virtual ~IUserRepository() = default;
    
    virtual bool save(const User& user) = 0;
    virtual bool update(const User& user) = 0;
    virtual bool remove(const std::string& userId) = 0;
    virtual std::unique_ptr<User> findById(const std::string& userId) = 0;
    virtual std::unique_ptr<User> findByUsername(const std::string& username) = 0;
    virtual std::vector<User> findAll() = 0;
    virtual std::vector<User> findByRole(UserRole role) = 0;
    virtual bool usernameExists(const std::string& username) = 0;
};

// Helper class for string serialization
class UserSerializer {
public:
    static void writeString(std::ofstream& ofs, const std::string& str) {
        size_t len = str.length();
        ofs.write(reinterpret_cast<const char*>(&len), sizeof(len));
        if (len > 0) {
            ofs.write(str.c_str(), len);
        }
    }
    
    static std::string readString(std::ifstream& ifs) {
        size_t len;
        ifs.read(reinterpret_cast<char*>(&len), sizeof(len));
        if (len == 0) return "";
        
        char* buffer = new char[len + 1];
        ifs.read(buffer, len);
        buffer[len] = '\0';
        std::string result(buffer);
        delete[] buffer;
        return result;
    }
};

// Binary User Repository Implementation
class UserBinaryRepository : public IUserRepository {
private:
    std::string filename;
    
    void writeUser(std::ofstream& ofs, const User& user) {
        UserSerializer::writeString(ofs, user.getUserId());
        UserSerializer::writeString(ofs, user.getUsername());
        UserSerializer::writeString(ofs, user.getPassword());
        UserSerializer::writeString(ofs, user.getFullName());
        UserSerializer::writeString(ofs, user.getEmail());
        
        UserRole role = user.getRole();
        ofs.write(reinterpret_cast<const char*>(&role), sizeof(role));
        
        UserSerializer::writeString(ofs, user.getLinkedEntityId());
        
        bool isActive = user.getIsActive();
        ofs.write(reinterpret_cast<const char*>(&isActive), sizeof(isActive));
        
        time_t createdAt = user.getCreatedAt();
        ofs.write(reinterpret_cast<const char*>(&createdAt), sizeof(createdAt));
        
        time_t lastLogin = user.getLastLogin();
        ofs.write(reinterpret_cast<const char*>(&lastLogin), sizeof(lastLogin));
    }
    
    User readUser(std::ifstream& ifs) {
        User user;
        
        user.setUserId(UserSerializer::readString(ifs));
        user.setUsername(UserSerializer::readString(ifs));
        user.setPassword(UserSerializer::readString(ifs));
        user.setFullName(UserSerializer::readString(ifs));
        user.setEmail(UserSerializer::readString(ifs));
        
        UserRole role;
        ifs.read(reinterpret_cast<char*>(&role), sizeof(role));
        user.setRole(role);
        
        user.setLinkedEntityId(UserSerializer::readString(ifs));
        
        bool isActive;
        ifs.read(reinterpret_cast<char*>(&isActive), sizeof(isActive));
        user.setIsActive(isActive);
        
        time_t createdAt;
        ifs.read(reinterpret_cast<char*>(&createdAt), sizeof(createdAt));
        user.setCreatedAt(createdAt);
        
        time_t lastLogin;
        ifs.read(reinterpret_cast<char*>(&lastLogin), sizeof(lastLogin));
        user.setLastLogin(lastLogin);
        
        return user;
    }
    
public:
    UserBinaryRepository(const std::string& file = "users.dat")
        : filename(file) {}
    
    bool save(const User& user) override {
        std::vector<User> users = findAll();
        users.push_back(user);
        
        std::ofstream ofs(filename, std::ios::binary | std::ios::trunc);
        if (!ofs) return false;
        
        size_t count = users.size();
        ofs.write(reinterpret_cast<const char*>(&count), sizeof(count));
        
        for (const auto& u : users) {
            writeUser(ofs, u);
        }
        
        ofs.close();
        return true;
    }
    
    bool update(const User& user) override {
        std::vector<User> users = findAll();
        bool found = false;
        
        for (auto& u : users) {
            if (u.getUserId() == user.getUserId()) {
                u = user;
                found = true;
                break;
            }
        }
        
        if (!found) return false;
        
        std::ofstream ofs(filename, std::ios::binary | std::ios::trunc);
        if (!ofs) return false;
        
        size_t count = users.size();
        ofs.write(reinterpret_cast<const char*>(&count), sizeof(count));
        
        for (const auto& u : users) {
            writeUser(ofs, u);
        }
        
        ofs.close();
        return true;
    }
    
    bool remove(const std::string& userId) override {
        std::vector<User> users = findAll();
        size_t initialSize = users.size();
        
        auto it = std::remove_if(users.begin(), users.end(),
            [&userId](const User& u) { return u.getUserId() == userId; });
        users.erase(it, users.end());
        
        if (users.size() == initialSize) return false;
        
        std::ofstream ofs(filename, std::ios::binary | std::ios::trunc);
        if (!ofs) return false;
        
        size_t count = users.size();
        ofs.write(reinterpret_cast<const char*>(&count), sizeof(count));
        
        for (const auto& u : users) {
            writeUser(ofs, u);
        }
        
        ofs.close();
        return true;
    }
    
    std::unique_ptr<User> findById(const std::string& userId) override {
        std::vector<User> users = findAll();
        
        for (const auto& u : users) {
            if (u.getUserId() == userId) {
                return std::make_unique<User>(u);
            }
        }
        
        return nullptr;
    }
    
    std::unique_ptr<User> findByUsername(const std::string& username) override {
        std::vector<User> users = findAll();
        
        for (const auto& u : users) {
            if (u.getUsername() == username) {
                return std::make_unique<User>(u);
            }
        }
        
        return nullptr;
    }
    
    std::vector<User> findAll() override {
        std::vector<User> users;
        std::ifstream ifs(filename, std::ios::binary);
        
        if (!ifs) return users;
        
        size_t count;
        ifs.read(reinterpret_cast<char*>(&count), sizeof(count));
        
        for (size_t i = 0; i < count; ++i) {
            users.push_back(readUser(ifs));
        }
        
        ifs.close();
        return users;
    }
    
    std::vector<User> findByRole(UserRole role) override {
        std::vector<User> users = findAll();
        std::vector<User> result;
        
        for (const auto& u : users) {
            if (u.getRole() == role) {
                result.push_back(u);
            }
        }
        
        return result;
    }
    
    bool usernameExists(const std::string& username) override {
        return findByUsername(username) != nullptr;
    }
};

// Authentication Service
class AuthenticationService {
private:
    std::shared_ptr<IUserRepository> userRepository;
    std::unique_ptr<User> currentUser;
    
    // Validation helpers
    bool isValidUsername(const std::string& username) const {
        if (username.length() < 3 || username.length() > 20) return false;
        
        if (!std::isalpha(static_cast<unsigned char>(username[0]))) return false;
        
        for (char c : username) {
            if (!std::isalnum(static_cast<unsigned char>(c)) && c != '_') return false;
        }
        
        return true;
    }
    
    bool isValidPassword(const std::string& password) const {
        if (password.length() < 6) return false;
        
        bool hasDigit = false;
        bool hasLetter = false;
        
        for (char c : password) {
            if (std::isdigit(static_cast<unsigned char>(c))) hasDigit = true;
            if (std::isalpha(static_cast<unsigned char>(c))) hasLetter = true;
        }
        
        return hasDigit && hasLetter;
    }
    
    bool isValidEmail(const std::string& email) const {
        size_t atPos = email.find('@');
        size_t dotPos = email.find('.', atPos);
        
        return (atPos != std::string::npos && 
                dotPos != std::string::npos && 
                atPos > 0 && 
                dotPos > atPos + 1 &&
                dotPos < email.length() - 1);
    }
    
    std::string generateUserId() const {
        time_t now = std::time(nullptr);
        return "USR" + std::to_string(now);
    }
    
public:
    AuthenticationService(std::shared_ptr<IUserRepository> userRepo)
        : userRepository(userRepo), currentUser(nullptr) {}
    
    struct RegistrationResult {
        bool success;
        std::string message;
        std::string userId;
    };
    
    RegistrationResult registerUser(const std::string& username, 
                                    const std::string& password,
                                    const std::string& fullName,
                                    const std::string& email,
                                    UserRole role,
                                    const std::string& linkedEntityId = "") {
        RegistrationResult result;
        result.success = false;
        
        if (!isValidUsername(username)) {
            result.message = "Invalid username. Must be 3-20 characters, start with letter, alphanumeric and underscore only.";
            return result;
        }
        
        if (userRepository->usernameExists(username)) {
            result.message = "Username already exists. Please choose another.";
            return result;
        }
        
        if (!isValidPassword(password)) {
            result.message = "Invalid password. Must be at least 6 characters with letters and digits.";
            return result;
        }
        
        if (fullName.empty() || fullName.length() < 3) {
            result.message = "Full name must be at least 3 characters.";
            return result;
        }
        
        if (!isValidEmail(email)) {
            result.message = "Invalid email format.";
            return result;
        }
        
        std::string userId = generateUserId();
        User newUser(userId, username, password, fullName, email, role, linkedEntityId);
        
        if (userRepository->save(newUser)) {
            result.success = true;
            result.message = "Registration successful!";
            result.userId = userId;
        } else {
            result.message = "Failed to save user. Please try again.";
        }
        
        return result;
    }
    
    struct LoginResult {
        bool success;
        std::string message;
        UserRole role;
    };
    
    LoginResult login(const std::string& username, const std::string& password) {
        LoginResult result;
        result.success = false;
        result.role = UserRole::NONE;
        
        auto user = userRepository->findByUsername(username);
        
        if (!user) {
            result.message = "Username not found.";
            return result;
        }
        
        if (!user->getIsActive()) {
            result.message = "Account is inactive. Please contact administrator.";
            return result;
        }
        
        if (!user->verifyPassword(password)) {
            result.message = "Incorrect password.";
            return result;
        }
        
        user->updateLastLogin();
        userRepository->update(*user);
        
        currentUser = std::move(user);
        
        result.success = true;
        result.message = "Login successful!";
        result.role = currentUser->getRole();
        
        return result;
    }
    
    void logout() {
        currentUser.reset();
    }
    
    User* getCurrentUser() const {
        return currentUser.get();
    }
    
    bool isLoggedIn() const {
        return currentUser != nullptr;
    }
    
    bool changePassword(const std::string& oldPassword, const std::string& newPassword) {
        if (!currentUser) return false;
        
        if (!currentUser->verifyPassword(oldPassword)) {
            return false;
        }
        
        if (!isValidPassword(newPassword)) {
            return false;
        }
        
        currentUser->setPassword(newPassword);
        return userRepository->update(*currentUser);
    }
};

#endif // USER_AUTHENTICATION_H