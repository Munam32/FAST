// ============================================================================
// TA and Attendant Binary Repository Implementations
// Completing the repository layer with consistent design patterns
// ============================================================================

#ifndef REMAINING_REPOSITORIES_H
#define REMAINING_REPOSITORIES_H

#include "RepositoryInterfaces.h"
#include "BinaryRepositories.h"
#include <fstream>
#include <algorithm>

// Teaching Assistant Binary Repository
class TABinaryRepository : public ITARepository {
private:
    std::string filename;

    void writeTA(std::ofstream& ofs, const TeachingAssistant& ta) {
        BinarySerializer::writeString(ofs, ta.getId());
        BinarySerializer::writeString(ofs, ta.getName());
        BinarySerializer::writeString(ofs, ta.getEmail());
        BinarySerializer::writeString(ofs, ta.getPhoneNumber());
        BinarySerializer::writeString(ofs, ta.getStudentId());
        BinarySerializer::writeString(ofs, ta.getProgram());
    }

    TeachingAssistant readTA(std::ifstream& ifs) {
        std::string id = BinarySerializer::readString(ifs);
        std::string name = BinarySerializer::readString(ifs);
        std::string email = BinarySerializer::readString(ifs);
        std::string phone = BinarySerializer::readString(ifs);
        std::string studId = BinarySerializer::readString(ifs);
        std::string program = BinarySerializer::readString(ifs);

        return TeachingAssistant(id, name, email, phone, studId, program);
    }

public:
    TABinaryRepository(const std::string& file = "tas.dat")
        : filename(file) {
    }

    bool save(const TeachingAssistant& ta) override {
        std::vector<TeachingAssistant> tas = findAll();
        tas.push_back(ta);

        std::ofstream ofs(filename, std::ios::binary | std::ios::trunc);
        if (!ofs) return false;

        size_t count = tas.size();
        ofs.write(reinterpret_cast<const char*>(&count), sizeof(count));

        for (const auto& t : tas) {
            writeTA(ofs, t);
        }

        ofs.close();
        return true;
    }

    bool update(const TeachingAssistant& ta) override {
        std::vector<TeachingAssistant> tas = findAll();
        auto it = std::find_if(tas.begin(), tas.end(),
            [&ta](const TeachingAssistant& t) { return t.getId() == ta.getId(); });

        if (it == tas.end()) return false;

        *it = ta;

        std::ofstream ofs(filename, std::ios::binary | std::ios::trunc);
        if (!ofs) return false;

        size_t count = tas.size();
        ofs.write(reinterpret_cast<const char*>(&count), sizeof(count));

        for (const auto& t : tas) {
            writeTA(ofs, t);
        }

        ofs.close();
        return true;
    }

    bool remove(const std::string& id) override {
        std::vector<TeachingAssistant> tas = findAll();
        auto initialSize = tas.size();

        tas.erase(
            std::remove_if(tas.begin(), tas.end(),
                [&id](const TeachingAssistant& t) { return t.getId() == id; }),
            tas.end()
        );

        if (tas.size() == initialSize) return false;

        std::ofstream ofs(filename, std::ios::binary | std::ios::trunc);
        if (!ofs) return false;

        size_t count = tas.size();
        ofs.write(reinterpret_cast<const char*>(&count), sizeof(count));

        for (const auto& t : tas) {
            writeTA(ofs, t);
        }

        ofs.close();
        return true;
    }

    std::unique_ptr<TeachingAssistant> findById(const std::string& id) override {
        std::vector<TeachingAssistant> tas = findAll();
        auto it = std::find_if(tas.begin(), tas.end(),
            [&id](const TeachingAssistant& t) { return t.getId() == id; });

        if (it == tas.end()) return nullptr;

        return std::make_unique<TeachingAssistant>(*it);
    }

    std::vector<TeachingAssistant> findAll() override {
        std::vector<TeachingAssistant> tas;
        std::ifstream ifs(filename, std::ios::binary);

        if (!ifs) return tas;

        size_t count;
        ifs.read(reinterpret_cast<char*>(&count), sizeof(count));

        for (size_t i = 0; i < count; ++i) {
            tas.push_back(readTA(ifs));
        }

        ifs.close();
        return tas;
    }

    std::vector<TeachingAssistant> findByProgram(const std::string& program) override {
        std::vector<TeachingAssistant> tas = findAll();
        std::vector<TeachingAssistant> result;

        std::copy_if(tas.begin(), tas.end(), std::back_inserter(result),
            [&program](const TeachingAssistant& t) { return t.getProgram() == program; });

        return result;
    }
};

// Attendant Binary Repository
class AttendantBinaryRepository : public IAttendantRepository {
private:
    std::string filename;

    void writeAttendant(std::ofstream& ofs, const Attendant& attendant) {
        BinarySerializer::writeString(ofs, attendant.getId());
        BinarySerializer::writeString(ofs, attendant.getName());
        BinarySerializer::writeString(ofs, attendant.getEmail());
        BinarySerializer::writeString(ofs, attendant.getPhoneNumber());
        BinarySerializer::writeString(ofs, attendant.getAssignedBuilding());
    }

    Attendant readAttendant(std::ifstream& ifs) {
        std::string id = BinarySerializer::readString(ifs);
        std::string name = BinarySerializer::readString(ifs);
        std::string email = BinarySerializer::readString(ifs);
        std::string phone = BinarySerializer::readString(ifs);
        std::string building = BinarySerializer::readString(ifs);

        return Attendant(id, name, email, phone, building);
    }

public:
    AttendantBinaryRepository(const std::string& file = "attendants.dat")
        : filename(file) {
    }

    bool save(const Attendant& attendant) override {
        std::vector<Attendant> attendants = findAll();
        attendants.push_back(attendant);

        std::ofstream ofs(filename, std::ios::binary | std::ios::trunc);
        if (!ofs) return false;

        size_t count = attendants.size();
        ofs.write(reinterpret_cast<const char*>(&count), sizeof(count));

        for (const auto& a : attendants) {
            writeAttendant(ofs, a);
        }

        ofs.close();
        return true;
    }

    bool update(const Attendant& attendant) override {
        std::vector<Attendant> attendants = findAll();
        auto it = std::find_if(attendants.begin(), attendants.end(),
            [&attendant](const Attendant& a) { return a.getId() == attendant.getId(); });

        if (it == attendants.end()) return false;

        *it = attendant;

        std::ofstream ofs(filename, std::ios::binary | std::ios::trunc);
        if (!ofs) return false;

        size_t count = attendants.size();
        ofs.write(reinterpret_cast<const char*>(&count), sizeof(count));

        for (const auto& a : attendants) {
            writeAttendant(ofs, a);
        }

        ofs.close();
        return true;
    }

    bool remove(const std::string& id) override {
        std::vector<Attendant> attendants = findAll();
        auto initialSize = attendants.size();

        attendants.erase(
            std::remove_if(attendants.begin(), attendants.end(),
                [&id](const Attendant& a) { return a.getId() == id; }),
            attendants.end()
        );

        if (attendants.size() == initialSize) return false;

        std::ofstream ofs(filename, std::ios::binary | std::ios::trunc);
        if (!ofs) return false;

        size_t count = attendants.size();
        ofs.write(reinterpret_cast<const char*>(&count), sizeof(count));

        for (const auto& a : attendants) {
            writeAttendant(ofs, a);
        }

        ofs.close();
        return true;
    }

    std::unique_ptr<Attendant> findById(const std::string& id) override {
        std::vector<Attendant> attendants = findAll();
        auto it = std::find_if(attendants.begin(), attendants.end(),
            [&id](const Attendant& a) { return a.getId() == id; });

        if (it == attendants.end()) return nullptr;

        return std::make_unique<Attendant>(*it);
    }

    std::vector<Attendant> findAll() override {
        std::vector<Attendant> attendants;
        std::ifstream ifs(filename, std::ios::binary);

        if (!ifs) return attendants;

        size_t count;
        ifs.read(reinterpret_cast<char*>(&count), sizeof(count));

        for (size_t i = 0; i < count; ++i) {
            attendants.push_back(readAttendant(ifs));
        }

        ifs.close();
        return attendants;
    }

    std::unique_ptr<Attendant> findByBuilding(const std::string& buildingName) override {
        std::vector<Attendant> attendants = findAll();
        auto it = std::find_if(attendants.begin(), attendants.end(),
            [&buildingName](const Attendant& a) {
                return a.getAssignedBuilding() == buildingName;
            });

        if (it == attendants.end()) return nullptr;

        return std::make_unique<Attendant>(*it);
    }
};

#endif // REMAINING_REPOSITORIES_H