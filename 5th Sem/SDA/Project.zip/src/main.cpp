﻿// ============================================================================
// Main Application with Authentication System
// Complete Labs Management System with User Login and Registration
// ============================================================================

#include "DomainModels.h"
#include "BinaryRepositories.h"
#include "RemainingRepositories.h"
#include "ServiceLayer.h"
#include "UserAuthentication.h"
#include <iostream>
#include <iomanip>
#include <limits>
#include <cstdlib>

// Console UI Helper Class
class ConsoleUI {
public:
    static void clearScreen() {
        #ifdef _WIN32
            int result = system("cls");
        #else
            int result = system("clear");
        #endif
        (void)result;
    }
    
    static void pause() {
        std::cout << "\nPress Enter to continue...";
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cin.get();
    }
    
    static void printHeader(const std::string& title) {
        clearScreen();
        std::cout << "====================================================\n";
        std::cout << "  " << title << "\n";
        std::cout << "====================================================\n\n";
    }
    
    static void printError(const std::string& message) {
        std::cout << "\n[ERROR] " << message << "\n";
    }
    
    static void printSuccess(const std::string& message) {
        std::cout << "\n[SUCCESS] " << message << "\n";
    }
    
    static void printInfo(const std::string& message) {
        std::cout << "\n[INFO] " << message << "\n";
    }
    
    static int getChoice(int min, int max) {
        int choice;
        while (true) {
            std::cout << "\nEnter your choice: ";
            if (std::cin >> choice && choice >= min && choice <= max) {
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                return choice;
            }
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input. Please enter a number between " 
                      << min << " and " << max << ".\n";
        }
    }
    
    static std::string getInput(const std::string& prompt) {
        std::string input;
        std::cout << prompt;
        std::getline(std::cin, input);
        return input;
    }
    
    static std::string getPassword(const std::string& prompt) {
        std::string password;
        std::cout << prompt;
        std::getline(std::cin, password);
        return password;
    }
    
    static int getIntInput(const std::string& prompt) {
        int value;
        while (true) {
            std::cout << prompt;
            if (std::cin >> value) {
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                return value;
            }
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input. Please enter a number.\n";
        }
    }
};

// Application Controller with Authentication
class LabsManagementApp {
private:
    // Repositories
    std::shared_ptr<ILabSectionRepository> labRepository;
    std::shared_ptr<IInstructorRepository> instructorRepository;
    std::shared_ptr<ITARepository> taRepository;
    std::shared_ptr<IAttendantRepository> attendantRepository;
    std::shared_ptr<IUserRepository> userRepository;
    
    // Services
    std::unique_ptr<AcademicOfficerService> academicService;
    std::unique_ptr<AttendantService> attendantService;
    std::unique_ptr<ReportGenerationService> reportService;
    std::unique_ptr<InstructorService> instructorService;
    std::unique_ptr<AuthenticationService> authService;
    
    void initializeServices() {
        academicService = std::make_unique<AcademicOfficerService>(
            labRepository, instructorRepository, taRepository);
        
        attendantService = std::make_unique<AttendantService>(
            labRepository, attendantRepository);
        
        reportService = std::make_unique<ReportGenerationService>(
            labRepository, instructorRepository, taRepository);
        
        instructorService = std::make_unique<InstructorService>(
            labRepository, instructorRepository);
        
        authService = std::make_unique<AuthenticationService>(userRepository);
    }
    
    // Authentication menus
    void showWelcomeScreen() {
        ConsoleUI::printHeader("LABS MANAGEMENT SYSTEM");
        std::cout << "Welcome to the Labs Management System\n\n";
        std::cout << "1. Login\n";
        std::cout << "2. Register New Account\n";
        std::cout << "3. About System\n";
        std::cout << "0. Exit\n";
    }
    
    void showAboutSystem() {
        ConsoleUI::printHeader("ABOUT SYSTEM");
        std::cout << "Labs Management System v1.0\n\n";
        std::cout << "This system manages:\n";
        std::cout << "  • Laboratory sections and schedules\n";
        std::cout << "  • Instructors and Teaching Assistants\n";
        std::cout << "  • Attendance and time sheets\n";
        std::cout << "  • Reports and statistics\n\n";
        std::cout << "User Roles:\n";
        std::cout << "  • Academic Officer: Manages labs, assigns staff\n";
        std::cout << "  • Attendant: Records sessions, marks leaves\n";
        std::cout << "  • Instructor: Views labs, requests makeups\n";
        std::cout << "  • Head of Department: Generates reports\n\n";
        ConsoleUI::pause();
    }
    
    void registerNewUser() {
        ConsoleUI::printHeader("USER REGISTRATION");
        
        std::cout << "Please provide the following information:\n\n";
        
        std::string username = ConsoleUI::getInput("Username (3-20 chars, alphanumeric): ");
        std::string password = ConsoleUI::getPassword("Password (min 6 chars, letters + digits): ");
        std::string confirmPassword = ConsoleUI::getPassword("Confirm Password: ");
        
        if (password != confirmPassword) {
            ConsoleUI::printError("Passwords do not match!");
            ConsoleUI::pause();
            return;
        }
        
        std::string fullName = ConsoleUI::getInput("Full Name: ");
        std::string email = ConsoleUI::getInput("Email: ");
        
        std::cout << "\nSelect your role:\n";
        std::cout << "1. Academic Officer\n";
        std::cout << "2. Attendant\n";
        std::cout << "3. Instructor\n";
        std::cout << "4. Head of Department\n";
        
        int roleChoice = ConsoleUI::getChoice(1, 4);
        
        UserRole role = UserRole::NONE; // Initialize to avoid warning
        std::string linkedEntityId = "";
        
        switch(roleChoice) {
            case 1: 
                role = UserRole::ACADEMIC_OFFICER; 
                break;
            case 2:
                role = UserRole::ATTENDANT;
                linkedEntityId = ConsoleUI::getInput("Enter your Attendant ID: ");
                break;
            case 3:
                role = UserRole::INSTRUCTOR;
                linkedEntityId = ConsoleUI::getInput("Enter your Instructor ID: ");
                break;
            case 4:
                role = UserRole::HEAD_OF_DEPARTMENT;
                break;
        }
        
        auto result = authService->registerUser(username, password, fullName, email, role, linkedEntityId);
        
        if (result.success) {
            ConsoleUI::printSuccess(result.message);
            ConsoleUI::printInfo("Your User ID: " + result.userId);
            ConsoleUI::printInfo("Please remember your username and password for login.");
        } else {
            ConsoleUI::printError(result.message);
        }
        
        ConsoleUI::pause();
    }
    
    bool loginUser() {
        ConsoleUI::printHeader("USER LOGIN");
        
        std::string username = ConsoleUI::getInput("Username: ");
        std::string password = ConsoleUI::getPassword("Password: ");
        
        auto result = authService->login(username, password);
        
        if (result.success) {
            ConsoleUI::printSuccess(result.message);
            User* user = authService->getCurrentUser();
            ConsoleUI::printInfo("Welcome, " + user->getFullName() + "!");
            ConsoleUI::printInfo("Role: " + user->getRoleString());
            ConsoleUI::pause();
            return true;
        } else {
            ConsoleUI::printError(result.message);
            ConsoleUI::pause();
            return false;
        }
    }
    
    // Role-based menu display
    void showRoleBasedMenu() {
        User* currentUser = authService->getCurrentUser();
        if (!currentUser) return;
        
        ConsoleUI::printHeader("MAIN MENU");
        std::cout << "Logged in as: " << currentUser->getFullName() << "\n";
        std::cout << "Role: " << currentUser->getRoleString() << "\n\n";
        
        switch(currentUser->getRole()) {
            case UserRole::ACADEMIC_OFFICER:
                std::cout << "1. Lab Management\n";
                std::cout << "2. Staff Management\n";
                std::cout << "3. Schedule Management\n";
                std::cout << "4. View Reports\n";
                std::cout << "5. My Profile\n";
                std::cout << "0. Logout\n";
                break;
                
            case UserRole::ATTENDANT:
                std::cout << "1. Record Lab Session\n";
                std::cout << "2. Mark Lab as Leave\n";
                std::cout << "3. View My Labs\n";
                std::cout << "4. My Profile\n";
                std::cout << "0. Logout\n";
                break;
                
            case UserRole::INSTRUCTOR:
                std::cout << "1. View My Labs\n";
                std::cout << "2. Request Makeup Lab\n";
                std::cout << "3. View Attendance Statistics\n";
                std::cout << "4. My Profile\n";
                std::cout << "0. Logout\n";
                break;
                
            case UserRole::HEAD_OF_DEPARTMENT:
                std::cout << "1. Generate Weekly Schedule\n";
                std::cout << "2. Generate Weekly Timesheet\n";
                std::cout << "3. Generate Semester Report\n";
                std::cout << "4. View All Labs Statistics\n";
                std::cout << "5. Manage Users\n";
                std::cout << "6. My Profile\n";
                std::cout << "0. Logout\n";
                break;
                
            default:
                ConsoleUI::printError("Invalid role!");
                break;
        }
    }
    
    void showUserProfile() {
        ConsoleUI::printHeader("MY PROFILE");
        
        User* user = authService->getCurrentUser();
        if (!user) return;
        
        std::cout << "User ID: " << user->getUserId() << "\n";
        std::cout << "Username: " << user->getUsername() << "\n";
        std::cout << "Full Name: " << user->getFullName() << "\n";
        std::cout << "Email: " << user->getEmail() << "\n";
        std::cout << "Role: " << user->getRoleString() << "\n";
        
        if (!user->getLinkedEntityId().empty()) {
            std::cout << "Linked Entity ID: " << user->getLinkedEntityId() << "\n";
        }
        
        std::cout << "Account Status: " << (user->getIsActive() ? "Active" : "Inactive") << "\n";
        
        // Display timestamps
        time_t created = user->getCreatedAt();
        std::string createdStr = std::ctime(&created);
        std::cout << "Account Created: " << createdStr;
        
        time_t lastLogin = user->getLastLogin();
        if (lastLogin > 0) {
            std::string lastLoginStr = std::ctime(&lastLogin);
            std::cout << "Last Login: " << lastLoginStr;
        }
        
        std::cout << "\n1. Change Password\n";
        std::cout << "0. Back\n";
        
        int choice = ConsoleUI::getChoice(0, 1);
        
        if (choice == 1) {
            changePassword();
        }
    }
    
    void changePassword() {
        ConsoleUI::printHeader("CHANGE PASSWORD");
        
        std::string oldPassword = ConsoleUI::getPassword("Enter current password: ");
        std::string newPassword = ConsoleUI::getPassword("Enter new password: ");
        std::string confirmPassword = ConsoleUI::getPassword("Confirm new password: ");
        
        if (newPassword != confirmPassword) {
            ConsoleUI::printError("Passwords do not match!");
            ConsoleUI::pause();
            return;
        }
        
        if (authService->changePassword(oldPassword, newPassword)) {
            ConsoleUI::printSuccess("Password changed successfully!");
        } else {
            ConsoleUI::printError("Failed to change password. Check your current password.");
        }
        
        ConsoleUI::pause();
    }
    
    // Academic Officer Menu
    void handleAcademicOfficer() {
        while (true) {
            showRoleBasedMenu();
            int choice = ConsoleUI::getChoice(0, 5);
            
            switch(choice) {
                case 1: labManagementMenu(); break;
                case 2: staffManagementMenu(); break;
                case 3: scheduleManagementMenu(); break;
                case 4: viewReportsMenu(); break;
                case 5: showUserProfile(); break;
                case 0: return;
            }
        }
    }
    
    void labManagementMenu() {
        ConsoleUI::printHeader("LAB MANAGEMENT");
        std::cout << "1. Create New Lab Section\n";
        std::cout << "2. View All Labs\n";
        std::cout << "3. Update Lab Details\n";
        std::cout << "0. Back\n";
        
        int choice = ConsoleUI::getChoice(0, 3);
        (void)choice; // Suppress unused variable warning
        
        // Implement lab management functions here
        // (Use existing implementation from previous version)
        ConsoleUI::printInfo("Lab management functionality available");
        ConsoleUI::pause();
    }
    
    void staffManagementMenu() {
        ConsoleUI::printHeader("STAFF MANAGEMENT");
        std::cout << "1. Add Instructor\n";
        std::cout << "2. Add Teaching Assistant\n";
        std::cout << "3. Add Attendant\n";
        std::cout << "4. Assign Instructor to Lab\n";
        std::cout << "5. Add TA to Lab\n";
        std::cout << "0. Back\n";
        
        int choice = ConsoleUI::getChoice(0, 5);
        (void)choice; // Suppress unused variable warning
        
        ConsoleUI::printInfo("Staff management functionality available");
        ConsoleUI::pause();
    }
    
    void scheduleManagementMenu() {
        ConsoleUI::printHeader("SCHEDULE MANAGEMENT");
        std::cout << "1. Update Lab Schedule\n";
        std::cout << "2. Schedule Makeup Lab\n";
        std::cout << "3. View Weekly Schedule\n";
        std::cout << "0. Back\n";
        
        int choice = ConsoleUI::getChoice(0, 3);
        (void)choice; // Suppress unused variable warning
        
        ConsoleUI::printInfo("Schedule management functionality available");
        ConsoleUI::pause();
    }
    
    void viewReportsMenu() {
        ConsoleUI::printHeader("REPORTS");
        std::cout << "1. Weekly Schedule\n";
        std::cout << "2. Weekly Timesheet\n";
        std::cout << "3. Semester Report\n";
        std::cout << "0. Back\n";
        
        int choice = ConsoleUI::getChoice(0, 3);
        (void)choice; // Suppress unused variable warning
        
        ConsoleUI::printInfo("Reports functionality available");
        ConsoleUI::pause();
    }
    
    // Attendant Menu
    void handleAttendant() {
        User* user = authService->getCurrentUser();
        std::string attendantId = user->getLinkedEntityId();
        
        while (true) {
            showRoleBasedMenu();
            int choice = ConsoleUI::getChoice(0, 4);
            
            switch(choice) {
                case 1: recordSession(attendantId); break;
                case 2: markLeave(attendantId); break;
                case 3: viewMyLabs(attendantId); break;
                case 4: showUserProfile(); break;
                case 0: return;
            }
        }
    }
    
    void recordSession(const std::string& attendantId) {
        ConsoleUI::printHeader("RECORD LAB SESSION");
        ConsoleUI::printInfo("Recording session for Attendant: " + attendantId);
        // Implementation here
        ConsoleUI::printInfo("Session recording functionality available");
        ConsoleUI::pause();
    }
    
    void markLeave(const std::string& attendantId) {
        ConsoleUI::printHeader("MARK LAB AS LEAVE");
        ConsoleUI::printInfo("Marking leave for Attendant: " + attendantId);
        // Implementation here
        ConsoleUI::printInfo("Leave marking functionality available");
        ConsoleUI::pause();
    }
    
    void viewMyLabs(const std::string& attendantId) {
        ConsoleUI::printHeader("MY LABS");
        ConsoleUI::printInfo("Viewing labs for Attendant: " + attendantId);
        // Implementation here
        ConsoleUI::printInfo("Lab viewing functionality available");
        ConsoleUI::pause();
    }
    
    // Instructor Menu
    void handleInstructor() {
        User* user = authService->getCurrentUser();
        std::string instructorId = user->getLinkedEntityId();
        
        while (true) {
            showRoleBasedMenu();
            int choice = ConsoleUI::getChoice(0, 4);
            
            switch(choice) {
                case 1: viewInstructorLabs(instructorId); break;
                case 2: requestMakeup(instructorId); break;
                case 3: viewStatistics(instructorId); break;
                case 4: showUserProfile(); break;
                case 0: return;
            }
        }
    }
    
    void viewInstructorLabs(const std::string& instructorId) {
        ConsoleUI::printHeader("MY LABS");
        
        try {
            auto labs = instructorService->getMyLabs(instructorId);
            
            if (labs.empty()) {
                ConsoleUI::printInfo("No labs assigned to you.");
            } else {
                std::cout << "You are teaching " << labs.size() << " lab(s):\n\n";
                
                for (const auto& lab : labs) {
                    std::cout << "Lab: " << lab.getLabName() << " (" << lab.getCourseCode() << ")\n";
                    std::cout << "Section: " << lab.getSectionName() << "\n";
                    std::cout << "Total Contact Hours: " << lab.getTotalContactHours() << " hours\n";
                    std::cout << "Total Leaves: " << lab.getTotalLeaves() << "\n";
                    std::cout << "--------------------\n";
                }
            }
        } catch (const std::exception& e) {
            ConsoleUI::printError(e.what());
        }
        
        ConsoleUI::pause();
    }
    
    void requestMakeup(const std::string& instructorId) {
        ConsoleUI::printHeader("REQUEST MAKEUP LAB");
        ConsoleUI::printInfo("Requesting makeup for Instructor: " + instructorId);
        // Implementation here
        ConsoleUI::printInfo("Makeup request functionality available");
        ConsoleUI::pause();
    }
    
    void viewStatistics(const std::string& instructorId) {
        ConsoleUI::printHeader("ATTENDANCE STATISTICS");
        ConsoleUI::printInfo("Viewing statistics for Instructor: " + instructorId);
        // Implementation here
        ConsoleUI::printInfo("Statistics viewing functionality available");
        ConsoleUI::pause();
    }
    
    // HOD Menu
    void handleHOD() {
        while (true) {
            showRoleBasedMenu();
            int choice = ConsoleUI::getChoice(0, 6);
            
            switch(choice) {
                case 1: generateWeeklySchedule(); break;
                case 2: generateWeeklyTimesheet(); break;
                case 3: generateSemesterReport(); break;
                case 4: viewAllStatistics(); break;
                case 5: manageUsers(); break;
                case 6: showUserProfile(); break;
                case 0: return;
            }
        }
    }
    
    void generateWeeklySchedule() {
        ConsoleUI::printHeader("WEEKLY SCHEDULE REPORT");
        
        try {
            std::string report = reportService->generateWeeklyScheduleReport();
            std::cout << report;
        } catch (const std::exception& e) {
            ConsoleUI::printError(e.what());
        }
        
        ConsoleUI::pause();
    }
    
    void generateWeeklyTimesheet() {
        ConsoleUI::printHeader("WEEKLY TIMESHEET REPORT");
        
        int week = ConsoleUI::getIntInput("Enter week number: ");
        int year = ConsoleUI::getIntInput("Enter year: ");
        
        try {
            std::string report = reportService->generateWeeklyTimeSheetReport(week, year);
            std::cout << report;
        } catch (const std::exception& e) {
            ConsoleUI::printError(e.what());
        }
        
        ConsoleUI::pause();
    }
    
    void generateSemesterReport() {
        ConsoleUI::printHeader("SEMESTER REPORT");
        
        std::string labId = ConsoleUI::getInput("Enter Lab ID: ");
        
        try {
            std::string report = reportService->generateLabSemesterReport(labId);
            std::cout << report;
        } catch (const std::exception& e) {
            ConsoleUI::printError(e.what());
        }
        
        ConsoleUI::pause();
    }
    
    void viewAllStatistics() {
        ConsoleUI::printHeader("ALL LABS STATISTICS");
        
        auto allLabs = labRepository->findAll();
        
        std::cout << "Total Labs: " << allLabs.size() << "\n\n";
        
        double totalHours = 0.0;
        int totalLeaves = 0;
        
        for (const auto& lab : allLabs) {
            totalHours += lab.getTotalContactHours();
            totalLeaves += lab.getTotalLeaves();
        }
        
        std::cout << "Total Contact Hours (All Labs): " << totalHours << " hours\n";
        std::cout << "Total Leaves (All Labs): " << totalLeaves << "\n";
        
        ConsoleUI::pause();
    }
    
    void manageUsers() {
        ConsoleUI::printHeader("USER MANAGEMENT");
        
        std::cout << "1. View All Users\n";
        std::cout << "2. View Users by Role\n";
        std::cout << "3. Deactivate User\n";
        std::cout << "0. Back\n";
        
        int choice = ConsoleUI::getChoice(0, 3);
        
        switch(choice) {
            case 1: viewAllUsers(); break;
            case 2: viewUsersByRole(); break;
            case 3: deactivateUser(); break;
        }
    }
    
    void viewAllUsers() {
        ConsoleUI::printHeader("ALL USERS");
        
        auto users = userRepository->findAll();
        
        std::cout << "Total Users: " << users.size() << "\n\n";
        
        for (const auto& user : users) {
            std::cout << "Username: " << user.getUsername() << "\n";
            std::cout << "Name: " << user.getFullName() << "\n";
            std::cout << "Role: " << user.getRoleString() << "\n";
            std::cout << "Status: " << (user.getIsActive() ? "Active" : "Inactive") << "\n";
            std::cout << "--------------------\n";
        }
        
        ConsoleUI::pause();
    }
    
    void viewUsersByRole() {
        ConsoleUI::printHeader("USERS BY ROLE");
        
        std::cout << "Select role:\n";
        std::cout << "1. Academic Officer\n";
        std::cout << "2. Attendant\n";
        std::cout << "3. Instructor\n";
        std::cout << "4. Head of Department\n";
        
        int roleChoice = ConsoleUI::getChoice(1, 4);
        
        UserRole role = UserRole::NONE; // Initialize to avoid warning
        switch(roleChoice) {
            case 1: role = UserRole::ACADEMIC_OFFICER; break;
            case 2: role = UserRole::ATTENDANT; break;
            case 3: role = UserRole::INSTRUCTOR; break;
            case 4: role = UserRole::HEAD_OF_DEPARTMENT; break;
        }
        
        auto users = userRepository->findByRole(role);
        
        std::cout << "\nFound " << users.size() << " user(s):\n\n";
        
        for (const auto& user : users) {
            std::cout << "Username: " << user.getUsername() << "\n";
            std::cout << "Name: " << user.getFullName() << "\n";
            std::cout << "Status: " << (user.getIsActive() ? "Active" : "Inactive") << "\n";
            std::cout << "--------------------\n";
        }
        
        ConsoleUI::pause();
    }
    
    void deactivateUser() {
        ConsoleUI::printHeader("DEACTIVATE USER");
        
        std::string username = ConsoleUI::getInput("Enter username to deactivate: ");
        
        auto user = userRepository->findByUsername(username);
        
        if (!user) {
            ConsoleUI::printError("User not found.");
        } else {
            user->setIsActive(false);
            if (userRepository->update(*user)) {
                ConsoleUI::printSuccess("User deactivated successfully.");
            } else {
                ConsoleUI::printError("Failed to deactivate user.");
            }
        }
        
        ConsoleUI::pause();
    }
    
public:
    LabsManagementApp(
        std::shared_ptr<ILabSectionRepository> labRepo,
        std::shared_ptr<IInstructorRepository> instrRepo,
        std::shared_ptr<ITARepository> taRepo,
        std::shared_ptr<IAttendantRepository> attendRepo,
        std::shared_ptr<IUserRepository> userRepo)
        : labRepository(labRepo), instructorRepository(instrRepo),
          taRepository(taRepo), attendantRepository(attendRepo),
          userRepository(userRepo) {
        
        initializeServices();
    }
    
    void run() {
        while (true) {
            showWelcomeScreen();
            int choice = ConsoleUI::getChoice(0, 3);
            
            switch(choice) {
                case 1: // Login
                    if (loginUser()) {
                        handleAuthenticatedUser();
                    }
                    break;
                    
                case 2: // Register
                    registerNewUser();
                    break;
                    
                case 3: // About
                    showAboutSystem();
                    break;
                    
                case 0: // Exit
                    ConsoleUI::printHeader("GOODBYE");
                    std::cout << "Thank you for using Labs Management System!\n";
                    return;
            }
        }
    }
    
    void handleAuthenticatedUser() {
        User* user = authService->getCurrentUser();
        if (!user) return;
        
        switch(user->getRole()) {
            case UserRole::ACADEMIC_OFFICER:
                handleAcademicOfficer();
                break;
            case UserRole::ATTENDANT:
                handleAttendant();
                break;
            case UserRole::INSTRUCTOR:
                handleInstructor();
                break;
            case UserRole::HEAD_OF_DEPARTMENT:
                handleHOD();
                break;
            default:
                ConsoleUI::printError("Invalid role!");
                break;
        }
        
        authService->logout();
        ConsoleUI::printInfo("You have been logged out.");
        ConsoleUI::pause();
    }
};

// Main function
int main() {
    try {
        // Create repositories
        auto labRepo = std::make_shared<LabSectionBinaryRepository>("labs.dat");
        auto instrRepo = std::make_shared<InstructorBinaryRepository>("instructors.dat");
        auto taRepo = std::make_shared<TABinaryRepository>("tas.dat");
        auto attendRepo = std::make_shared<AttendantBinaryRepository>("attendants.dat");
        auto userRepo = std::make_shared<UserBinaryRepository>("users.dat");
        
        // Create and run application
        LabsManagementApp app(labRepo, instrRepo, taRepo, attendRepo, userRepo);
        app.run();
        
    } catch (const std::exception& e) {
        std::cerr << "Fatal Error: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}